"""Historical price series for Kalshi and Polymarket markets, normalized to one schema.

Verified endpoints:
  Kalshi      GET /trade-api/v2/series/{series}/markets/{ticker}/candlesticks
              -> {"candlesticks": [...], "ticker": "..."}
  Polymarket  GET https://clob.polymarket.com/prices-history?market={token}&interval=&fidelity=
              -> {"history": [{"t": 1784246412, "p": 0.0485}, ...]}

Candlestick item fields are read through `pick()` because Kalshi has shipped both a
flat and a nested (price.open/high/low/close) shape across API versions.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

import httpx

UA = "prediction-market-history-actor/1.0 (Apify actor)"
KALSHI = "https://api.elections.kalshi.com/trade-api/v2"
POLY_GAMMA = "https://gamma-api.polymarket.com"
POLY_CLOB = "https://clob.polymarket.com"


def pick(d: dict, *names, default=None):
    for n in names:
        if isinstance(d, dict) and d.get(n) is not None:
            return d[n]
    return default


def _f(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _dollars(v):
    """Kalshi prices come as cents (0-100) in some versions, dollars (0-1) in others."""
    f = _f(v)
    if f is None:
        return None
    return round(f / 100.0, 4) if f > 1.0 else round(f, 4)


def _iso(ts) -> str | None:
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).isoformat(timespec="seconds")
    except (TypeError, ValueError, OSError):
        return None


def series_of(ticker: str) -> str:
    """KXHIGHNY-26SEP07-B79.5 -> KXHIGHNY"""
    return (ticker or "").split("-")[0]


def _as_list(v):
    if isinstance(v, list):
        return v
    if isinstance(v, str):
        try:
            p = json.loads(v)
            return p if isinstance(p, list) else []
        except ValueError:
            return []
    return []


# --------------------------------------------------------------------------- #
# Market discovery (so callers can pass a search term instead of raw tickers)
# --------------------------------------------------------------------------- #
async def discover_kalshi(client: httpx.AsyncClient, limit: int, status: str | None,
                          series: str | None, terms: list[str]) -> list[dict]:
    out, cursor = [], None
    scanned = 0
    while len(out) < limit and scanned < 20000:
        params: dict = {"limit": 1000}
        if status and status != "any":
            params["status"] = status
        if series:
            params["series_ticker"] = series
        if cursor:
            params["cursor"] = cursor
        r = await client.get(f"{KALSHI}/markets", params=params, timeout=60)
        r.raise_for_status()
        j = r.json()
        batch = j.get("markets") or []
        if not batch:
            break
        scanned += len(batch)
        for m in batch:
            title = pick(m, "title", default="")
            if terms and not any(t.lower() in f"{title} {pick(m,'ticker',default='')}".lower() for t in terms):
                continue
            out.append({"exchange": "kalshi", "market_id": pick(m, "ticker"),
                        "question": title, "close_time": pick(m, "close_time"),
                        "status": pick(m, "status")})
            if len(out) >= limit:
                break
        cursor = j.get("cursor")
        if not cursor:
            break
    return out


async def discover_polymarket(client: httpx.AsyncClient, limit: int, status: str | None,
                              terms: list[str]) -> list[dict]:
    out, offset = [], 0
    while len(out) < limit and offset < 20000:
        params: dict = {"limit": 100, "offset": offset, "order": "volume24hr", "ascending": "false"}
        if status == "open":
            params["closed"] = "false"
            params["active"] = "true"
        elif status in ("closed", "settled"):
            params["closed"] = "true"
        r = await client.get(f"{POLY_GAMMA}/markets", params=params, timeout=60)
        r.raise_for_status()
        batch = r.json()
        if not isinstance(batch, list) or not batch:
            break
        offset += len(batch)
        for m in batch:
            q = pick(m, "question", default="")
            if terms and not any(t.lower() in q.lower() for t in terms):
                continue
            tokens = _as_list(pick(m, "clobTokenIds", default=[]))
            outcomes = _as_list(pick(m, "outcomes", default=[]))
            if not tokens:
                continue
            # index 0 is the Yes leg unless outcomes say otherwise
            yes_idx = 0
            for i, name in enumerate(outcomes):
                if str(name).strip().lower() == "yes":
                    yes_idx = i
                    break
            out.append({"exchange": "polymarket", "market_id": str(pick(m, "id", default="")),
                        "question": q, "token_id": str(tokens[min(yes_idx, len(tokens) - 1)]),
                        "slug": pick(m, "slug"), "close_time": pick(m, "endDate"),
                        "status": "closed" if pick(m, "closed") else "active"})
            if len(out) >= limit:
                break
        if len(batch) < 100:
            break
    return out


# --------------------------------------------------------------------------- #
# Price history
# --------------------------------------------------------------------------- #
def normalize_candlestick(c: dict, market: dict) -> dict:
    price = c.get("price") if isinstance(c.get("price"), dict) else {}
    bid = c.get("yes_bid") if isinstance(c.get("yes_bid"), dict) else {}
    ask = c.get("yes_ask") if isinstance(c.get("yes_ask"), dict) else {}
    ts = pick(c, "end_period_ts", "ts", "timestamp")
    return {
        "type": "price_point",
        "exchange": "kalshi",
        "market_id": market.get("market_id"),
        "question": market.get("question"),
        "timestamp": ts,
        "time_utc": _iso(ts),
        "price": _dollars(pick(price, "close", "mean") if price else pick(c, "close", "price")),
        "open": _dollars(pick(price, "open") if price else pick(c, "open")),
        "high": _dollars(pick(price, "high") if price else pick(c, "high")),
        "low": _dollars(pick(price, "low") if price else pick(c, "low")),
        "close": _dollars(pick(price, "close") if price else pick(c, "close")),
        "mean": _dollars(pick(price, "mean") if price else None),
        "yes_bid": _dollars(pick(bid, "close") if bid else pick(c, "yes_bid")),
        "yes_ask": _dollars(pick(ask, "close") if ask else pick(c, "yes_ask")),
        "volume": _f(pick(c, "volume")),
        "open_interest": _f(pick(c, "open_interest")),
    }


async def kalshi_history(client: httpx.AsyncClient, market: dict, start_ts: int, end_ts: int,
                         period_minutes: int) -> list[dict]:
    ticker = market["market_id"]
    url = f"{KALSHI}/series/{series_of(ticker)}/markets/{ticker}/candlesticks"
    r = await client.get(url, params={"start_ts": start_ts, "end_ts": end_ts,
                                      "period_interval": period_minutes}, timeout=60)
    if r.status_code == 404:
        return []
    r.raise_for_status()
    items = r.json().get("candlesticks") or []
    return [normalize_candlestick(c, market) for c in items]


async def polymarket_history(client: httpx.AsyncClient, market: dict, start_ts: int, end_ts: int,
                             fidelity_minutes: int) -> list[dict]:
    r = await client.get(f"{POLY_CLOB}/prices-history",
                         params={"market": market["token_id"], "startTs": start_ts,
                                 "endTs": end_ts, "fidelity": fidelity_minutes}, timeout=60)
    if r.status_code in (404, 400):
        return []
    r.raise_for_status()
    items = r.json().get("history") or []
    out = []
    for p in items:
        ts = pick(p, "t", "timestamp")
        price = _f(pick(p, "p", "price"))
        out.append({
            "type": "price_point",
            "exchange": "polymarket",
            "market_id": market.get("market_id"),
            "question": market.get("question"),
            "timestamp": ts,
            "time_utc": _iso(ts),
            "price": price,
            "open": None, "high": None, "low": None, "close": price, "mean": None,
            "yes_bid": None, "yes_ask": None, "volume": None, "open_interest": None,
        })
    return out


def summarize(points: list[dict], market: dict) -> dict | None:
    """One row per market: the shape of the series, so a caller can rank markets
    without paying for every tick."""
    prices = [p["price"] for p in points if p.get("price") is not None]
    if not prices:
        return None
    first, last = prices[0], prices[-1]
    return {
        "type": "market_summary",
        "exchange": market.get("exchange"),
        "market_id": market.get("market_id"),
        "question": market.get("question"),
        "points": len(points),
        "first_price": first,
        "last_price": last,
        "min_price": min(prices),
        "max_price": max(prices),
        "range": round(max(prices) - min(prices), 4),
        "change": round(last - first, 4),
        "first_time_utc": points[0].get("time_utc"),
        "last_time_utc": points[-1].get("time_utc"),
        "close_time": market.get("close_time"),
        "status": market.get("status"),
    }
