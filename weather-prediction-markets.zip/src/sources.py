"""Data sources: IEM daily climate (NWS CLI), NWS hourly observations, Open-Meteo multi-model forecasts.
All free public APIs, no keys. Every function returns a list of flat dicts ready for dataset push."""
from __future__ import annotations

import asyncio
from datetime import date, datetime, timedelta, timezone

import httpx

UA = "weather-prediction-markets-actor/1.0 (Apify actor; contact via Apify store)"
IEM_CLI = "https://mesonet.agron.iastate.edu/json/cli.py"
NWS = "https://api.weather.gov"
OPEN_METEO = "https://api.open-meteo.com/v1/forecast"
OPEN_METEO_GEO = "https://geocoding-api.open-meteo.com/v1/search"

MODELS = ["gfs_seamless", "ecmwf_ifs025", "icon_seamless", "gem_seamless", "jma_seamless", "best_match"]


def _num(v):
    """IEM uses 'M' (missing) and 'T' (trace). Keep trace as 0.0 with flag; missing -> None."""
    if v in ("M", None, ""):
        return None
    if v == "T":
        return 0.0
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _iso(d: date) -> str:
    return d.isoformat()


async def fetch_climate_days(client: httpx.AsyncClient, station: str, start: date, end: date) -> list[dict]:
    """Official NWS Daily Climate Report (CLI) values via IEM. This is what Kalshi/Polymarket temperature
    markets settle on. One request per station-year."""
    out: list[dict] = []
    for year in range(start.year, end.year + 1):
        r = await client.get(IEM_CLI, params={"station": station.upper(), "year": year}, timeout=60)
        r.raise_for_status()
        for row in r.json().get("results", []):
            d = date.fromisoformat(row["valid"])
            if d < start or d > end:
                continue
            out.append({
                "type": "climate_day",
                "station": row.get("station"),
                "station_name": row.get("name"),
                "state": row.get("state"),
                "wfo": row.get("wfo"),
                "date": row["valid"],
                "high_f": _num(row.get("high")),
                "high_time": row.get("high_time"),
                "high_normal_f": _num(row.get("high_normal")),
                "high_record_f": _num(row.get("high_record")),
                "low_f": _num(row.get("low")),
                "low_time": row.get("low_time"),
                "low_normal_f": _num(row.get("low_normal")),
                "low_record_f": _num(row.get("low_record")),
                "precip_in": _num(row.get("precip")),
                "precip_trace": row.get("precip") == "T",
                "precip_normal_in": _num(row.get("precip_normal")),
                "snow_in": _num(row.get("snow")),
                "snow_trace": row.get("snow") == "T",
                "snow_depth_in": _num(row.get("snowdepth")),
                "avg_wind_mph": _num(row.get("average_wind_speed")),
                "max_wind_mph": _num(row.get("highest_wind_speed")),
                "max_gust_mph": _num(row.get("highest_gust_speed")),
                "avg_sky_cover": _num(row.get("average_sky_cover")),
                "source": "NWS Daily Climate Report (CLI) via IEM",
                "source_product": row.get("product"),
                "source_url": ("https://mesonet.agron.iastate.edu" + row["link"]) if row.get("link") else None,
            })
    return out


def _q(props: dict, key: str):
    v = props.get(key) or {}
    return v.get("value") if isinstance(v, dict) else None


def c_to_f(c):
    return None if c is None else round(c * 9 / 5 + 32, 1)


async def fetch_nws_observations(client: httpx.AsyncClient, station: str, start: datetime, end: datetime, limit: int = 500) -> list[dict]:
    """Hourly/METAR observations from api.weather.gov (last ~7 days available)."""
    params = {"start": start.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
              "end": end.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "limit": min(limit, 500)}
    r = await client.get(f"{NWS}/stations/{station.upper()}/observations", params=params, timeout=60,
                         headers={"User-Agent": UA, "Accept": "application/geo+json"})
    r.raise_for_status()
    out = []
    for f in r.json().get("features", []):
        p = f.get("properties", {})
        temp_c = _q(p, "temperature")
        out.append({
            "type": "observation",
            "station": station.upper(),
            "timestamp_utc": p.get("timestamp"),
            "temp_f": c_to_f(temp_c), "temp_c": temp_c,
            "dewpoint_c": _q(p, "dewpoint"),
            "humidity_pct": _q(p, "relativeHumidity"),
            "wind_kmh": _q(p, "windSpeed"), "wind_gust_kmh": _q(p, "windGust"), "wind_dir_deg": _q(p, "windDirection"),
            "pressure_pa": _q(p, "barometricPressure"),
            "precip_last_hour_mm": _q(p, "precipitationLastHour"),
            "visibility_m": _q(p, "visibility"),
            "description": p.get("textDescription"),
            "raw_metar": p.get("rawMessage"),
            "source": "NWS api.weather.gov",
        })
    return out


async def geocode(client: httpx.AsyncClient, name: str) -> dict | None:
    r = await client.get(OPEN_METEO_GEO, params={"name": name, "count": 1, "language": "en", "format": "json"}, timeout=30)
    r.raise_for_status()
    res = r.json().get("results") or []
    if not res:
        return None
    g = res[0]
    return {"name": g.get("name"), "country": g.get("country"), "lat": g["latitude"], "lon": g["longitude"], "timezone": g.get("timezone")}


async def fetch_forecasts(client: httpx.AsyncClient, label: str, lat: float, lon: float, days: int, models: list[str],
                          unit: str = "fahrenheit", timezone_name: str = "auto") -> list[dict]:
    """Multi-model daily forecast (max/min temp, precip) from Open-Meteo. One record per model per day."""
    params = {"latitude": lat, "longitude": lon, "daily": "temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max",
              "models": ",".join(models), "timezone": timezone_name, "forecast_days": max(1, min(days, 16)), "temperature_unit": unit,
              "precipitation_unit": "inch" if unit == "fahrenheit" else "mm"}
    r = await client.get(OPEN_METEO, params=params, timeout=60)
    r.raise_for_status()
    j = r.json()
    daily = j.get("daily", {})
    dates = daily.get("time", [])
    issued = datetime.now(timezone.utc).isoformat(timespec="seconds")

    def series(var: str, model: str) -> list:
        """Open-Meteo suffixes each variable with the model name when several models are
        requested, and omits the suffix for a single model. Fall back to a prefix scan so a
        change in their naming does not silently produce empty rows."""
        for key in (f"{var}_{model}", var):
            if isinstance(daily.get(key), list):
                return daily[key]
        for key, val in daily.items():
            if key.startswith(var) and model in key and isinstance(val, list):
                return val
        return []

    out = []
    for m in models:
        tmax = series("temperature_2m_max", m)
        tmin = series("temperature_2m_min", m)
        prec = series("precipitation_sum", m)
        pop = series("precipitation_probability_max", m)
        if not tmax:
            continue  # model returned nothing for this location
        for i, d in enumerate(dates):
            out.append({
                "type": "forecast_day", "location": label, "lat": lat, "lon": lon, "timezone": j.get("timezone"),
                "date": d, "model": m, "issued_at_utc": issued,
                "tmax": tmax[i] if i < len(tmax) else None, "tmin": tmin[i] if i < len(tmin) else None,
                "temp_unit": "F" if unit == "fahrenheit" else "C",
                "precip_sum": prec[i] if i < len(prec) else None, "precip_unit": params["precipitation_unit"],
                "precip_prob_max_pct": pop[i] if i < len(pop) else None,
                "source": "Open-Meteo",
            })
    # consensus row per day
    for d in dates:
        rows = [x for x in out if x["date"] == d and x["tmax"] is not None]
        if rows:
            out.append({"type": "forecast_day", "location": label, "lat": lat, "lon": lon, "timezone": j.get("timezone"), "date": d,
                        "model": "consensus_mean", "issued_at_utc": issued,
                        "tmax": round(sum(x["tmax"] for x in rows) / len(rows), 1),
                        "tmin": round(sum(x["tmin"] for x in rows if x["tmin"] is not None) / max(1, len([x for x in rows if x["tmin"] is not None])), 1),
                        "temp_unit": rows[0]["temp_unit"], "precip_sum": None, "precip_unit": params["precipitation_unit"],
                        "precip_prob_max_pct": None, "source": "Open-Meteo (mean of models)",
                        "models_count": len(rows), "tmax_spread": round(max(x["tmax"] for x in rows) - min(x["tmax"] for x in rows), 1)})
    return out
