"""Kick.com channels, live status, VODs and category discovery."""
from __future__ import annotations

import asyncio

import httpx
from apify import Actor

from .sources import HEADERS, fetch_category, fetch_channel, fetch_videos

EVENT_CHANNEL = "channel"
EVENT_VIDEO = "video"
EVENT_LIVE = "live-channel"


async def _budget(event_name: str, wanted: int) -> int:
    try:
        cm = Actor.get_charging_manager()
        allowed = cm.calculate_max_event_charge_count_within_limit(event_name)
    except Exception:
        return wanted
    return wanted if allowed is None else max(0, min(wanted, allowed))


async def _push(records: list[dict], event_name: str) -> int:
    if not records:
        return 0
    allowed = await _budget(event_name, len(records))
    if allowed < len(records):
        Actor.log.warning(f"Budget limit for '{event_name}': pushing {allowed} of {len(records)} rows.")
    records = records[:allowed]
    if not records:
        return 0
    await Actor.push_data(records, charged_event_name=event_name)
    return len(records)


async def main() -> None:
    async with Actor:
        inp = await Actor.get_input() or {}

        channels = [c for c in (inp.get("channels") or []) if c and str(c).strip()]
        categories = [c for c in (inp.get("categories") or []) if c and str(c).strip()]
        include_videos = bool(inp.get("includeVideos", False))
        videos_per_channel = int(inp.get("videosPerChannel") or 20)
        max_per_category = int(inp.get("maxChannelsPerCategory") or 100)
        min_viewers = int(inp.get("minViewers") or 0)
        concurrency = max(1, min(int(inp.get("concurrency") or 5), 15))

        if not channels and not categories:
            Actor.log.warning("Nothing to do: give at least one channel slug or category slug.")
            await Actor.set_value("SUMMARY", {"channel": 0, "video": 0, "live_channel": 0, "errors": 0})
            return

        proxy_cfg = await Actor.create_proxy_configuration(
            actor_proxy_input=inp.get("proxyConfiguration")
        )
        proxy_url = await proxy_cfg.new_url() if proxy_cfg else None
        if proxy_url:
            Actor.log.info("Using Apify proxy.")

        totals = {"channel": 0, "video": 0, "live_channel": 0, "errors": 0}
        sem = asyncio.Semaphore(concurrency)

        client_kwargs = {"headers": HEADERS, "follow_redirects": True, "timeout": 60}
        if proxy_url:
            client_kwargs["proxy"] = proxy_url

        async with httpx.AsyncClient(**client_kwargs) as client:

            async def one_channel(slug: str):
                async with sem:
                    try:
                        ch = await fetch_channel(client, str(slug))
                        n = await _push([ch], EVENT_CHANNEL)
                        totals["channel"] += n
                        state = "live" if ch.get("is_live") else "offline"
                        Actor.log.info(f"{slug}: {state}, {ch.get('followers')} followers.")

                        if include_videos:
                            vids = await fetch_videos(client, str(slug), videos_per_channel)
                            totals["video"] += await _push(vids, EVENT_VIDEO)
                            Actor.log.info(f"{slug}: {len(vids)} videos.")
                    except httpx.HTTPStatusError as e:
                        totals["errors"] += 1
                        if e.response.status_code == 404:
                            Actor.log.warning(f"{slug}: channel not found.")
                        elif e.response.status_code in (403, 429):
                            Actor.log.error(
                                f"{slug}: blocked ({e.response.status_code}). "
                                "Enable Apify Proxy (residential) in the input to get past Cloudflare."
                            )
                        else:
                            Actor.log.error(f"{slug}: HTTP {e.response.status_code}.")
                    except Exception as e:
                        totals["errors"] += 1
                        Actor.log.exception(f"{slug}: failed: {e}")

            await asyncio.gather(*(one_channel(s) for s in channels))

            for cat in categories:
                try:
                    rows = await fetch_category(client, str(cat), max_per_category)
                    if min_viewers:
                        rows = [r for r in rows if (r.get("live_viewers") or 0) >= min_viewers]
                    rows.sort(key=lambda r: r.get("live_viewers") or 0, reverse=True)
                    totals["live_channel"] += await _push(rows, EVENT_LIVE)
                    Actor.log.info(f"category '{cat}': {len(rows)} live channels.")
                except Exception as e:
                    totals["errors"] += 1
                    Actor.log.exception(f"category '{cat}': failed: {e}")

        await Actor.set_value("SUMMARY", totals)
        Actor.log.info(f"Done. channels={totals['channel']} videos={totals['video']} "
                       f"live={totals['live_channel']} errors={totals['errors']}")


if __name__ == "__main__":
    asyncio.run(main())
