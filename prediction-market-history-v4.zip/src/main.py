"""Historical price series for Kalshi and Polymarket markets."""
from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone

import httpx
from apify import Actor

from .sources import (UA, discover_kalshi, discover_polymarket, kalshi_history,
                      polymarket_history, summarize)

EVENT_POINT = "price-point"
EVENT_SUMMARY = "market-summary"


async def _budget(event_name: str, wanted: int) -> int:
    try:
        cm = Actor.get_charging_manager()
        allowed = cm.calculate_max_event_charge_count_within_limit(event_name)
    except Exception:
        return wanted
    return wanted if allowed is None else max(0, min(wanted, allowed))


async def _push(records: list[dict], event_name: str) -> int:
    if not records:
        return 0
    allowed = await _budget(event_name, len(records))
    if allowed < len(records):
        Actor.log.warning(f"Budget limit for '{event_name}': pushing {allowed} of {len(records)} rows.")
    records = records[:allowed]
    if not records:
        return 0
    await Actor.push_data(records, charged_event_name=event_name)
    return len(records)


def _ts(value, default: datetime) -> int:
    if value:
        try:
            s = str(value)[:19].replace("Z", "")
            return int(datetime.fromisoformat(s).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            pass
    return int(default.timestamp())


async def main() -> None:
    async with Actor:
        inp = await Actor.get_input() or {}

        exchanges = [e.lower() for e in (inp.get("exchanges") or ["kalshi", "polymarket"])]
        tickers = [t.strip() for t in (inp.get("kalshiTickers") or []) if str(t).strip()]
        tokens = [t.strip() for t in (inp.get("polymarketTokenIds") or []) if str(t).strip()]
        search = [s.strip() for s in (inp.get("search") or []) if str(s).strip()]
        series = (inp.get("kalshiSeriesTicker") or "").strip() or None
        status = (inp.get("status") or "any").lower()
        max_markets = int(inp.get("maxMarkets") or 25)
        granularity = int(inp.get("granularityMinutes") or 60)
        max_points = int(inp.get("maxPointsPerMarket") or 1000)
        want_points = bool(inp.get("includePricePoints", True))
        want_summary = bool(inp.get("includeSummary", True))
        concurrency = max(1, min(int(inp.get("concurrency") or 4), 10))

        now = datetime.now(timezone.utc)
        end_ts = _ts(inp.get("endDate"), now)
        start_ts = _ts(inp.get("startDate"), now - timedelta(days=int(inp.get("historyDays") or 30)))
        if start_ts > end_ts:
            start_ts, end_ts = end_ts, start_ts

        totals = {"price_point": 0, "market_summary": 0, "markets_scanned": 0, "errors": 0}

        async with httpx.AsyncClient(headers={"User-Agent": UA}, follow_redirects=True) as client:
            markets: list[dict] = []

            # explicit ids win; otherwise discover
            for t in tickers:
                markets.append({"exchange": "kalshi", "market_id": t, "question": None})
            for t in tokens:
                markets.append({"exchange": "polymarket", "market_id": t, "token_id": t, "question": None})

            if not markets:
                if "kalshi" in exchanges:
                    try:
                        found = await discover_kalshi(client, max_markets, status, series, search)
                        Actor.log.info(f"Kalshi: {len(found)} markets matched.")
                        if not found and search and not series:
                            Actor.log.warning(
                                "Kalshi has tens of thousands of open markets and no title search, so a "
                                "keyword may not appear in the pages scanned. Set 'kalshiSeriesTicker' to "
                                "target a series directly - KXHIGHNY for New York daily high temperature, "
                                "for example - or pass exact tickers in 'kalshiTickers'."
                            )
                        markets.extend(found)
                    except Exception as e:
                        totals["errors"] += 1
                        Actor.log.exception(f"Kalshi discovery failed: {e}")
                if "polymarket" in exchanges:
                    try:
                        found = await discover_polymarket(client, max_markets, status, search)
                        Actor.log.info(f"Polymarket: {len(found)} markets matched.")
                        markets.extend(found)
                    except Exception as e:
                        totals["errors"] += 1
                        Actor.log.exception(f"Polymarket discovery failed: {e}")

            markets = markets[: max_markets * 2 if not tickers and not tokens else len(markets)]
            totals["markets_scanned"] = len(markets)
            if not markets:
                Actor.log.warning("No markets to pull history for. Give tickers/token ids, or widen the search.")

            sem = asyncio.Semaphore(concurrency)
            summaries: list[dict] = []

            async def one(market: dict):
                async with sem:
                    try:
                        if market["exchange"] == "kalshi":
                            pts = await kalshi_history(client, market, start_ts, end_ts, granularity)
                        else:
                            if not market.get("token_id"):
                                return
                            pts = await polymarket_history(client, market, start_ts, end_ts, granularity)
                        pts = pts[:max_points]
                        if not pts:
                            Actor.log.info(f"{market['market_id']}: no history in range.")
                            return
                        if want_summary:
                            s = summarize(pts, market)
                            if s:
                                summaries.append(s)
                        if want_points:
                            totals["price_point"] += await _push(pts, EVENT_POINT)
                        Actor.log.info(f"{market['exchange']} {market['market_id']}: {len(pts)} points.")
                    except httpx.HTTPStatusError as e:
                        totals["errors"] += 1
                        Actor.log.error(f"{market['market_id']}: HTTP {e.response.status_code}.")
                    except Exception as e:
                        totals["errors"] += 1
                        Actor.log.exception(f"{market['market_id']}: failed: {e}")

            await asyncio.gather(*(one(m) for m in markets))

            if want_summary and summaries:
                summaries.sort(key=lambda s: s.get("range") or 0, reverse=True)
                totals["market_summary"] = await _push(summaries, EVENT_SUMMARY)

        await Actor.set_value("SUMMARY", totals)
        Actor.log.info(f"Done. points={totals['price_point']} summaries={totals['market_summary']} "
                       f"markets={totals['markets_scanned']} errors={totals['errors']}")


if __name__ == "__main__":
    asyncio.run(main())
