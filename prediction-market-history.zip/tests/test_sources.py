"""Offline tests. Polymarket history items below are a verbatim capture of a live response."""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.sources import (  # noqa: E402
    discover_polymarket, kalshi_history, normalize_candlestick,
    polymarket_history, series_of, summarize,
)

MARKET_K = {"exchange": "kalshi", "market_id": "KXHIGHNY-26SEP07-B79.5",
            "question": "Will the maximum temperature be 79-80 on Sep 7, 2026?",
            "close_time": "2026-09-07T23:30:00Z", "status": "active"}
MARKET_P = {"exchange": "polymarket", "market_id": "559651", "token_id": "3233822019",
            "question": "Xi Jinping out before 2027?", "close_time": "2027-01-01T04:59:00Z",
            "status": "active"}

# Kalshi has shipped both shapes; both must normalize identically.
CANDLE_NESTED = {
    "end_period_ts": 1788652800,
    "price": {"open": 42, "high": 51, "low": 40, "close": 47, "mean": 45},
    "yes_bid": {"open": 41, "close": 46}, "yes_ask": {"open": 43, "close": 48},
    "volume": 1200, "open_interest": 8800,
}
CANDLE_FLAT = {
    "end_period_ts": 1788652800,
    "open": 0.42, "high": 0.51, "low": 0.40, "close": 0.47,
    "yes_bid": 0.46, "yes_ask": 0.48, "volume": 1200, "open_interest": 8800,
}

# Verbatim from clob.polymarket.com/prices-history
POLY_HISTORY = {"history": [{"t": 1784246412, "p": 0.0485},
                            {"t": 1784332809, "p": 0.0495},
                            {"t": 1784419212, "p": 0.0455}]}


def test_series_of():
    assert series_of("KXHIGHNY-26SEP07-B79.5") == "KXHIGHNY"
    assert series_of("KXHIGHNY") == "KXHIGHNY"
    assert series_of("") == ""


def test_candlestick_nested_cents():
    r = normalize_candlestick(CANDLE_NESTED, MARKET_K)
    assert r["type"] == "price_point" and r["exchange"] == "kalshi"
    assert r["open"] == 0.42 and r["high"] == 0.51 and r["low"] == 0.40 and r["close"] == 0.47
    assert r["price"] == 0.47, "price falls back to close"
    assert r["mean"] == 0.45
    assert r["yes_bid"] == 0.46 and r["yes_ask"] == 0.48
    assert r["volume"] == 1200.0 and r["open_interest"] == 8800.0
    assert r["time_utc"] == "2026-09-06T00:00:00+00:00"
    assert r["market_id"] == "KXHIGHNY-26SEP07-B79.5"


def test_candlestick_flat_dollars_gives_same_numbers():
    a = normalize_candlestick(CANDLE_NESTED, MARKET_K)
    b = normalize_candlestick(CANDLE_FLAT, MARKET_K)
    for k in ("open", "high", "low", "close", "price", "yes_bid", "yes_ask"):
        assert a[k] == b[k], f"{k} differs between the nested and flat shapes"


def test_candlestick_bad_timestamp_is_survivable():
    r = normalize_candlestick({**CANDLE_NESTED, "end_period_ts": None}, MARKET_K)
    assert r["time_utc"] is None and r["price"] == 0.47


@pytest.mark.asyncio
@respx.mock
async def test_kalshi_history_builds_the_series_url():
    route = respx.get(
        "https://api.elections.kalshi.com/trade-api/v2/series/KXHIGHNY/markets/KXHIGHNY-26SEP07-B79.5/candlesticks"
    ).mock(return_value=httpx.Response(200, json={"candlesticks": [CANDLE_NESTED] * 3,
                                                  "ticker": "KXHIGHNY-26SEP07-B79.5"}))
    async with httpx.AsyncClient() as c:
        rows = await kalshi_history(c, MARKET_K, 1788566400, 1788652800, 60)
    assert route.called, "the series segment must be derived from the market ticker"
    assert len(rows) == 3 and all(r["exchange"] == "kalshi" for r in rows)


@pytest.mark.asyncio
@respx.mock
async def test_kalshi_history_missing_market_returns_empty():
    respx.get(url__regex=r".*/candlesticks").mock(return_value=httpx.Response(404, json={}))
    async with httpx.AsyncClient() as c:
        assert await kalshi_history(c, MARKET_K, 0, 1, 60) == []


@pytest.mark.asyncio
@respx.mock
async def test_polymarket_history_real_payload():
    respx.get("https://clob.polymarket.com/prices-history").mock(
        return_value=httpx.Response(200, json=POLY_HISTORY))
    async with httpx.AsyncClient() as c:
        rows = await polymarket_history(c, MARKET_P, 0, 9999999999, 1440)
    assert len(rows) == 3
    assert rows[0]["price"] == 0.0485 and rows[0]["close"] == 0.0485
    assert rows[0]["timestamp"] == 1784246412
    assert rows[0]["time_utc"].startswith("2026-")
    assert rows[0]["open"] is None, "Polymarket gives a single price, not OHLC"
    assert rows[0]["question"] == "Xi Jinping out before 2027?"


@pytest.mark.asyncio
@respx.mock
async def test_polymarket_history_empty_is_not_an_error():
    respx.get("https://clob.polymarket.com/prices-history").mock(
        return_value=httpx.Response(200, json={"history": []}))
    async with httpx.AsyncClient() as c:
        assert await polymarket_history(c, MARKET_P, 0, 1, 60) == []


def test_summarize_describes_the_series():
    pts = [
        {"price": 0.20, "time_utc": "2026-09-01T00:00:00+00:00"},
        {"price": 0.65, "time_utc": "2026-09-02T00:00:00+00:00"},
        {"price": 0.10, "time_utc": "2026-09-03T00:00:00+00:00"},
        {"price": 0.44, "time_utc": "2026-09-04T00:00:00+00:00"},
    ]
    s = summarize(pts, MARKET_K)
    assert s["type"] == "market_summary"
    assert s["points"] == 4
    assert s["first_price"] == 0.20 and s["last_price"] == 0.44
    assert s["min_price"] == 0.10 and s["max_price"] == 0.65
    assert s["range"] == pytest.approx(0.55)
    assert s["change"] == pytest.approx(0.24)
    assert s["first_time_utc"] == "2026-09-01T00:00:00+00:00"
    assert s["close_time"] == "2026-09-07T23:30:00Z"


def test_summarize_returns_none_without_prices():
    assert summarize([{"price": None}], MARKET_K) is None
    assert summarize([], MARKET_K) is None


@pytest.mark.asyncio
@respx.mock
async def test_discover_polymarket_extracts_the_yes_token():
    respx.get("https://gamma-api.polymarket.com/markets").mock(
        return_value=httpx.Response(200, json=[{
            "id": "1", "question": "Will it rain in NYC?", "slug": "rain-nyc",
            "outcomes": '["No", "Yes"]',
            "clobTokenIds": '["tokenNO", "tokenYES"]',
            "endDate": "2026-10-01T00:00:00Z", "closed": False,
        }]))
    async with httpx.AsyncClient() as c:
        found = await discover_polymarket(c, 10, "open", [])
    assert len(found) == 1
    assert found[0]["token_id"] == "tokenYES", "must follow the outcomes order, not assume index 0"


@pytest.mark.asyncio
@respx.mock
async def test_discover_polymarket_skips_markets_without_tokens():
    respx.get("https://gamma-api.polymarket.com/markets").mock(
        return_value=httpx.Response(200, json=[{"id": "1", "question": "No tokens here"}]))
    async with httpx.AsyncClient() as c:
        assert await discover_polymarket(c, 10, "open", []) == []


@pytest.mark.asyncio
@respx.mock
async def test_discover_polymarket_search_filter():
    respx.get("https://gamma-api.polymarket.com/markets").mock(
        return_value=httpx.Response(200, json=[
            {"id": "1", "question": "Temperature in NYC above 80?", "outcomes": '["Yes","No"]',
             "clobTokenIds": '["a","b"]'},
            {"id": "2", "question": "Who wins the election?", "outcomes": '["Yes","No"]',
             "clobTokenIds": '["c","d"]'},
        ]))
    async with httpx.AsyncClient() as c:
        found = await discover_polymarket(c, 10, "open", ["temperature"])
    assert len(found) == 1 and found[0]["market_id"] == "1"
