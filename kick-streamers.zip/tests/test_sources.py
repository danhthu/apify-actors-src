"""Offline tests against captures of the live kick.com/api/v2 responses."""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.sources import fetch_category, fetch_channel, fetch_videos, normalize_channel, normalize_video  # noqa: E402

CHANNEL_OFFLINE = {
    "id": 668, "user_id": 676, "slug": "xqc", "is_banned": False,
    "playback_url": "https://example/hls.m3u8", "vod_enabled": True,
    "subscription_enabled": True, "is_affiliate": True,
    "followers_count": "1783402",
    "subscriber_badges": [{"id": 1, "months": 1}, {"id": 2, "months": 3}],
    "banner_image": {"url": "https://files.kick.com/banner.jpg"},
    "livestream": None, "role": None, "muted": False, "follower_badges": [],
    "offline_banner_image": None, "verified": True,
    "recent_categories": [
        {"id": 15, "name": "Just Chatting", "slug": "just-chatting", "viewers": 120345},
        {"id": 28, "name": "Slots", "slug": "slots", "viewers": 34000},
    ],
    "can_host": True,
    "user": {"id": 676, "username": "xQc", "bio": "juicer", "instagram": "xqcow",
             "twitter": "xQc", "youtube": "xQcOW", "discord": "",
             "profile_pic": "https://files.kick.com/pfp.jpg"},
    "chatroom": {"id": 668, "chat_mode": "public", "slow_mode": False,
                 "followers_mode": True, "subscribers_mode": False, "message_interval": 0},
}

CHANNEL_LIVE = {
    **CHANNEL_OFFLINE,
    "livestream": {
        "id": 99887, "session_title": "LIVE NOW", "viewer_count": 42311,
        "start_time": "2026-09-06T12:00:00Z", "is_mature": False, "language": "English",
        "categories": [{"id": 15, "name": "Just Chatting", "slug": "just-chatting", "viewers": 42311}],
        "thumbnail": {"src": "https://files.kick.com/thumb.jpg"},
    },
}

VIDEO = {
    "id": 5551, "channel_id": 668,
    "session_title": "DRAMA NEWS VIDEOS",
    "created_at": "2026-09-05T18:00:00Z",
    "duration": 14400000, "views": 250000, "viewer_count": 38000,
    "categories": [{"id": 15, "name": "Just Chatting", "slug": "just-chatting", "viewers": 38000}],
    "thumbnail": {"src": "https://files.kick.com/vodthumb.jpg"},
    "video": {"uuid": "a1b2c3d4", "views": 250000, "status": "completed"},
    "source": "https://stream.kick.com/vod.m3u8",
    "slug": "drama-news", "is_live": False, "is_mature": False,
}


def test_channel_offline():
    c = normalize_channel(CHANNEL_OFFLINE)
    assert c["type"] == "channel" and c["slug"] == "xqc"
    assert c["followers"] == 1783402, "followers_count arrives as a string and must become an int"
    assert c["is_live"] is False
    assert "live_viewers" not in c
    assert c["verified"] is True and c["subscription_enabled"] is True
    assert c["subscriber_badge_tiers"] == 2
    assert c["primary_category"] == "Just Chatting"
    assert c["twitter"] == "xQc" and c["instagram"] == "xqcow"
    assert c["discord"] is None, "an empty social handle must be None, not an empty string"
    assert c["chat_followers_only"] is True and c["chat_subscribers_only"] is False
    assert c["banner_image"] == "https://files.kick.com/banner.jpg"
    assert c["channel_url"] == "https://kick.com/xqc"


def test_channel_live_carries_stream_fields():
    c = normalize_channel(CHANNEL_LIVE)
    assert c["is_live"] is True
    assert c["live_viewers"] == 42311
    assert c["live_title"] == "LIVE NOW"
    assert c["live_started_at"] == "2026-09-06T12:00:00Z"
    assert c["live_categories"][0]["name"] == "Just Chatting"
    assert c["live_thumbnail"] == "https://files.kick.com/thumb.jpg"


def test_video_normalization():
    v = normalize_video(VIDEO, "xqc")
    assert v["type"] == "video" and v["video_id"] == 5551
    assert v["duration_ms"] == 14400000
    assert v["duration_minutes"] == 240.0, "4 hours in milliseconds must read as 240 minutes"
    assert v["views"] == 250000 and v["peak_viewers"] == 38000
    assert v["primary_category"] == "Just Chatting"
    assert v["video_url"] == "https://kick.com/xqc/videos/a1b2c3d4"


def test_video_without_uuid_has_no_url():
    v = normalize_video({**VIDEO, "video": {}}, "xqc")
    assert v["video_url"] is None
    assert v["video_uuid"] is None


@pytest.mark.asyncio
@respx.mock
async def test_fetch_channel_normalizes_the_slug():
    route = respx.get("https://kick.com/api/v2/channels/xqc").mock(
        return_value=httpx.Response(200, json=CHANNEL_OFFLINE))
    async with httpx.AsyncClient() as c:
        ch = await fetch_channel(c, "  @XQC ")
    assert route.called, "leading @, spaces and capitals must be stripped before the request"
    assert ch["slug"] == "xqc"


@pytest.mark.asyncio
@respx.mock
async def test_fetch_videos_respects_limit_and_accepts_both_shapes():
    respx.get("https://kick.com/api/v2/channels/xqc/videos").mock(
        return_value=httpx.Response(200, json=[VIDEO] * 30))
    async with httpx.AsyncClient() as c:
        rows = await fetch_videos(c, "xqc", 5)
    assert len(rows) == 5

    respx.get("https://kick.com/api/v2/channels/xqc/videos").mock(
        return_value=httpx.Response(200, json={"data": [VIDEO] * 3}))
    async with httpx.AsyncClient() as c:
        rows = await fetch_videos(c, "xqc", 10)
    assert len(rows) == 3, "a {data: [...]} envelope must work as well as a bare array"


@pytest.mark.asyncio
@respx.mock
async def test_fetch_channel_raises_on_404():
    respx.get("https://kick.com/api/v2/channels/nope").mock(return_value=httpx.Response(404, json={}))
    async with httpx.AsyncClient() as c:
        with pytest.raises(httpx.HTTPStatusError):
            await fetch_channel(c, "nope")


LIVE_ITEM = {
    "channel_id": 668, "session_title": "big stream", "viewer_count": 5000,
    "start_time": "2026-09-06T12:00:00Z", "is_mature": False, "language": "English",
    "categories": [{"id": 15, "name": "Just Chatting", "slug": "just-chatting", "viewers": 5000}],
    "thumbnail": {"src": "https://files.kick.com/t.jpg"},
    "channel": {"id": 668, "slug": "xqc", "user": {"username": "xQc"}},
}


@pytest.mark.asyncio
@respx.mock
async def test_fetch_category_pages_and_stops():
    pages = [{"data": [LIVE_ITEM] * 50}, {"data": [LIVE_ITEM] * 7}, {"data": []}]

    def responder(request):
        return httpx.Response(200, json=pages.pop(0) if pages else {"data": []})

    respx.get("https://kick.com/api/v2/categories/just-chatting/livestreams").mock(side_effect=responder)
    async with httpx.AsyncClient() as c:
        rows = await fetch_category(c, "just-chatting", 500)
    assert len(rows) == 57
    assert rows[0]["type"] == "live_channel"
    assert rows[0]["slug"] == "xqc" and rows[0]["username"] == "xQc"
    assert rows[0]["channel_url"] == "https://kick.com/xqc"


@pytest.mark.asyncio
@respx.mock
async def test_fetch_category_missing_category_returns_empty():
    respx.get("https://kick.com/api/v2/categories/nope/livestreams").mock(
        return_value=httpx.Response(404, json={}))
    async with httpx.AsyncClient() as c:
        assert await fetch_category(c, "nope", 100) == []
