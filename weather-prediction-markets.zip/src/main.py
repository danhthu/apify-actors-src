"""Weather data for prediction-market traders (Kalshi / Polymarket).

Three record types, all billed per result:
  climate_day  - official NWS Daily Climate Report values (what temperature markets settle on)
  observation  - hourly/METAR observations for intraday tracking
  forecast_day - multi-model daily forecast + consensus row with model spread

Charging respects the user's per-run budget: we never push more rows than we are
allowed to charge for.
"""
from __future__ import annotations

import asyncio
from datetime import date, datetime, timedelta, timezone

import httpx
from apify import Actor

from .sources import MODELS, UA, fetch_climate_days, fetch_forecasts, fetch_nws_observations, geocode

EVENT_CLIMATE = "climate-day"
EVENT_OBSERVATION = "observation"
EVENT_FORECAST = "forecast-day"

# Station -> (label, lat, lon). The stations Kalshi/Polymarket temperature markets settle on.
KALSHI_STATIONS = {
    "KNYC": ("New York City, NY (Central Park)", 40.7794, -73.9692),
    "KLAX": ("Los Angeles, CA (LAX)", 33.9382, -118.3866),
    "KORD": ("Chicago, IL (O'Hare)", 41.9603, -87.9316),
    "KAUS": ("Austin, TX (Camp Mabry)", 30.3208, -97.7600),
    "KMIA": ("Miami, FL", 25.7906, -80.3164),
    "KDEN": ("Denver, CO", 39.8467, -104.6567),
    "KPHL": ("Philadelphia, PA", 39.8683, -75.2311),
    "KHOU": ("Houston, TX (Hobby)", 29.6372, -95.2822),
    "KSEA": ("Seattle, WA", 47.4444, -122.3138),
    "KBOS": ("Boston, MA", 42.3606, -71.0106),
    "KDCA": ("Washington, DC (National)", 38.8483, -77.0342),
    "KATL": ("Atlanta, GA", 33.6301, -84.4418),
    "KDFW": ("Dallas-Fort Worth, TX", 32.8978, -97.0189),
    "KPHX": ("Phoenix, AZ", 33.4278, -112.0039),
    "KLAS": ("Las Vegas, NV", 36.0719, -115.1634),
    "KMSP": ("Minneapolis, MN", 44.8831, -93.2289),
    "KDTW": ("Detroit, MI", 42.2314, -83.3308),
    "KSFO": ("San Francisco, CA", 37.6197, -122.3647),
}


def _parse_date(v, default: date) -> date:
    if not v:
        return default
    if isinstance(v, date):
        return v
    try:
        return date.fromisoformat(str(v)[:10])
    except ValueError:
        return default


async def _budget(event_name: str, wanted: int) -> int:
    """How many rows of this event type we may still charge for."""
    try:
        cm = Actor.get_charging_manager()
        allowed = cm.calculate_max_event_charge_count_within_limit(event_name)
    except Exception:  # not running under PPE (local run / rental) -> no limit
        return wanted
    if allowed is None:
        return wanted
    return max(0, min(wanted, allowed))


async def _push(records: list[dict], event_name: str) -> int:
    if not records:
        return 0
    allowed = await _budget(event_name, len(records))
    if allowed < len(records):
        Actor.log.warning(
            f"Budget limit reached for '{event_name}': pushing {allowed} of {len(records)} rows. "
            "Raise the run's max cost to get the rest."
        )
    records = records[:allowed]
    if not records:
        return 0
    await Actor.push_data(records, charged_event_name=event_name)
    return len(records)


async def main() -> None:
    async with Actor:
        inp = await Actor.get_input() or {}

        stations = [s.strip().upper() for s in (inp.get("stations") or []) if s and s.strip()]
        cities = [c.strip() for c in (inp.get("cities") or []) if c and c.strip()]
        include_climate = inp.get("includeClimate", True)
        include_obs = inp.get("includeObservations", False)
        include_fc = inp.get("includeForecast", True)
        history_days = int(inp.get("historyDays") or 30)
        forecast_days = int(inp.get("forecastDays") or 7)
        models = inp.get("models") or MODELS
        unit = "celsius" if str(inp.get("temperatureUnit", "fahrenheit")).lower().startswith("c") else "fahrenheit"

        if not stations and not cities:
            stations = ["KNYC"]
            Actor.log.info("No stations or cities given - defaulting to KNYC (New York, Central Park).")

        today = datetime.now(timezone.utc).date()
        end = _parse_date(inp.get("endDate"), today)
        start = _parse_date(inp.get("startDate"), end - timedelta(days=max(0, history_days - 1)))
        if start > end:
            start, end = end, start

        totals = {"climate_day": 0, "observation": 0, "forecast_day": 0, "errors": 0}

        async with httpx.AsyncClient(headers={"User-Agent": UA}, follow_redirects=True) as client:
            # ---- station-based records ----
            for st in stations:
                label, lat, lon = KALSHI_STATIONS.get(st, (st, None, None))

                if include_climate:
                    try:
                        rows = await fetch_climate_days(client, st, start, end)
                        totals["climate_day"] += await _push(rows, EVENT_CLIMATE)
                        Actor.log.info(f"{st}: {len(rows)} daily climate records ({start} to {end}).")
                    except Exception as e:
                        totals["errors"] += 1
                        Actor.log.exception(f"{st}: daily climate fetch failed: {e}")

                if include_obs:
                    try:
                        obs_start = datetime.combine(max(start, today - timedelta(days=7)), datetime.min.time(), timezone.utc)
                        obs_end = datetime.now(timezone.utc)
                        rows = await fetch_nws_observations(client, st, obs_start, obs_end)
                        totals["observation"] += await _push(rows, EVENT_OBSERVATION)
                        Actor.log.info(f"{st}: {len(rows)} observations.")
                    except Exception as e:
                        totals["errors"] += 1
                        Actor.log.exception(f"{st}: observations fetch failed: {e}")

                if include_fc and lat is not None:
                    try:
                        rows = await fetch_forecasts(client, label, lat, lon, forecast_days, models, unit)
                        for r in rows:
                            r["station"] = st
                        totals["forecast_day"] += await _push(rows, EVENT_FORECAST)
                        Actor.log.info(f"{st}: {len(rows)} forecast rows across {len(models)} models.")
                    except Exception as e:
                        totals["errors"] += 1
                        Actor.log.exception(f"{st}: forecast fetch failed: {e}")
                elif include_fc and lat is None:
                    Actor.log.warning(f"{st}: not a known market station, so no coordinates for a forecast. "
                                      "Add the place to 'cities' to get forecasts for it.")

            # ---- city-based forecasts ----
            for city in cities:
                try:
                    g = await geocode(client, city)
                    if not g:
                        Actor.log.warning(f"Could not geocode '{city}' - skipped.")
                        continue
                    label = f"{g['name']}, {g.get('country') or ''}".strip().rstrip(",")
                    if include_fc:
                        rows = await fetch_forecasts(client, label, g["lat"], g["lon"], forecast_days, models, unit)
                        totals["forecast_day"] += await _push(rows, EVENT_FORECAST)
                        Actor.log.info(f"{label}: {len(rows)} forecast rows.")
                except Exception as e:
                    totals["errors"] += 1
                    Actor.log.exception(f"{city}: failed: {e}")

        await Actor.set_value("SUMMARY", totals)
        Actor.log.info(
            f"Done. climate_day={totals['climate_day']} observation={totals['observation']} "
            f"forecast_day={totals['forecast_day']} errors={totals['errors']}"
        )


if __name__ == "__main__":
    asyncio.run(main())
