# Kick.com Scraper — Channels, Live Status, VODs & Category Discovery

Channel data from **Kick.com**: follower counts, social handles, live status and viewer counts, past broadcasts with duration and views, and — the part most Kick actors skip — **discovery of every channel currently live in a category**, so you can find streamers you do not already know the name of.

## What you get

### `channel`

```json
{
  "type": "channel",
  "slug": "xqc",
  "username": "xQc",
  "followers": 1783402,
  "verified": true,
  "is_live": true,
  "live_title": "LIVE NOW",
  "live_viewers": 42311,
  "live_started_at": "2026-09-06T12:00:00Z",
  "primary_category": "Just Chatting",
  "subscription_enabled": true,
  "subscriber_badge_tiers": 2,
  "twitter": "xQc",
  "instagram": "xqcow",
  "youtube": "xQcOW",
  "chat_followers_only": true,
  "channel_url": "https://kick.com/xqc"
}
```

Social handles come through as their own fields because the main reason people pull this data is sponsorship outreach, and a creator's other platforms decide the deal.

### `video` — past broadcasts

Title, `created_at`, `duration_minutes`, `views`, `peak_viewers`, category and a direct VOD link. Follower count tells you how big a channel is; peak viewers across recent broadcasts tells you whether it is actually growing.

### `live_channel` — category discovery

Give a category slug (`just-chatting`, `slots`, `gta-v`, `fortnite`) and get every channel live in it right now, sorted by viewers, with title, language, start time and link. Filter out the small ones with `minViewers`.

## Example input

Track specific channels:

```json
{ "channels": ["xqc", "adinross", "trainwreckstv"], "includeVideos": true, "videosPerChannel": 20 }
```

Find sponsorship candidates in a category:

```json
{ "categories": ["just-chatting", "slots"], "maxChannelsPerCategory": 200, "minViewers": 500 }
```

Cheap hourly live-status check:

```json
{ "channels": ["xqc"], "includeVideos": false }
```

## Pricing

| Record | Price |
|---|---|
| `channel` | $0.003 |
| `video` | $0.002 |
| `live_channel` | $0.002 |

Monitoring 50 channels every hour costs about **$0.15 per hour**. Comparable Kick actors charge $0.015 per channel — five times more for less data.

## Notes and limits

- Kick sits behind Cloudflare. Small runs usually pass through directly; for large or frequent runs turn on Apify Proxy (residential) in the input. If a request is blocked the actor logs it and keeps going instead of dying.
- A channel that does not exist is logged as a warning and skipped — one bad slug never kills the run.
- Follower counts arrive from the API as strings and are returned as integers.
- Fields that come back empty (a creator with no Discord, say) are `null`, not `""`, so filters behave predictably.
- Chat settings (`chat_mode`, followers-only, subscribers-only, slow mode) are included, which matters if you are building moderation or chat-analysis tooling.

## Use from an AI agent

Callable through Apify's MCP server — an agent can check whether a streamer is live, or pull the top of a category, without any Kick-specific code.

## Support

Open an issue on the actor page. Requests for clips, chat history, or extra fields are welcome.
