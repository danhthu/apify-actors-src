"""Kick.com public API: channels, livestream state, VODs and categories.

Verified against live responses. Kick sits behind Cloudflare, so requests carry a browser
User-Agent and the actor is expected to run through Apify's proxy in production.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone

import httpx

BASE = "https://kick.com/api/v2"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")
HEADERS = {"User-Agent": UA, "Accept": "application/json", "Accept-Language": "en-US,en;q=0.9"}


def _i(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _img(obj):
    if isinstance(obj, dict):
        return obj.get("src") or obj.get("url")
    return obj if isinstance(obj, str) else None


def _categories(items) -> list[dict]:
    out = []
    for c in items or []:
        if not isinstance(c, dict):
            continue
        out.append({"id": c.get("id"), "name": c.get("name"), "slug": c.get("slug"),
                    "viewers": _i(c.get("viewers"))})
    return out


def normalize_channel(j: dict) -> dict:
    user = j.get("user") or {}
    ls = j.get("livestream") or None
    chat = j.get("chatroom") or {}
    cats = _categories(j.get("recent_categories"))
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    rec = {
        "type": "channel",
        "channel_id": j.get("id"),
        "user_id": j.get("user_id"),
        "slug": j.get("slug"),
        "username": user.get("username"),
        "bio": user.get("bio"),
        "profile_pic": user.get("profile_pic"),
        "banner_image": _img(j.get("banner_image")),
        "followers": _i(j.get("followers_count")),
        "verified": bool(j.get("verified")),
        "is_banned": bool(j.get("is_banned")),
        "is_affiliate": bool(j.get("is_affiliate")),
        "subscription_enabled": bool(j.get("subscription_enabled")),
        "vod_enabled": bool(j.get("vod_enabled")),
        "can_host": bool(j.get("can_host")),
        "subscriber_badge_tiers": len(j.get("subscriber_badges") or []),
        # socials matter to anyone buying this for sponsorship outreach
        "instagram": user.get("instagram") or None,
        "twitter": user.get("twitter") or None,
        "youtube": user.get("youtube") or None,
        "discord": user.get("discord") or None,
        "tiktok": user.get("tiktok") or None,
        "facebook": user.get("facebook") or None,
        "chat_mode": chat.get("chat_mode"),
        "chat_followers_only": bool(chat.get("followers_mode")),
        "chat_subscribers_only": bool(chat.get("subscribers_mode")),
        "chat_slow_mode": bool(chat.get("slow_mode")),
        "recent_categories": cats,
        "primary_category": cats[0]["name"] if cats else None,
        "is_live": ls is not None,
        "channel_url": f"https://kick.com/{j.get('slug')}" if j.get("slug") else None,
        "fetched_at": now,
    }
    if ls:
        rec.update({
            "live_id": ls.get("id"),
            "live_title": ls.get("session_title"),
            "live_viewers": _i(ls.get("viewer_count")),
            "live_started_at": ls.get("start_time") or ls.get("created_at"),
            "live_is_mature": bool(ls.get("is_mature")),
            "live_language": ls.get("language"),
            "live_categories": _categories(ls.get("categories")),
            "live_thumbnail": _img(ls.get("thumbnail")),
        })
    return rec


def normalize_video(v: dict, channel_slug: str | None = None) -> dict:
    vid = v.get("video") or {}
    duration_ms = _i(v.get("duration")) or 0
    cats = _categories(v.get("categories"))
    return {
        "type": "video",
        "video_id": v.get("id"),
        "channel_id": v.get("channel_id"),
        "channel_slug": channel_slug,
        "title": v.get("session_title"),
        "created_at": v.get("created_at"),
        "duration_ms": duration_ms,
        "duration_minutes": round(duration_ms / 60000, 1) if duration_ms else None,
        "views": _i(v.get("views")),
        "peak_viewers": _i(v.get("viewer_count")),
        "categories": cats,
        "primary_category": cats[0]["name"] if cats else None,
        "is_mature": bool(v.get("is_mature")),
        "thumbnail": _img(v.get("thumbnail")),
        "video_uuid": vid.get("uuid"),
        "stream_url": v.get("source"),
        "video_url": (f"https://kick.com/{channel_slug}/videos/{vid.get('uuid')}"
                      if channel_slug and vid.get("uuid") else None),
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


async def fetch_channel(client: httpx.AsyncClient, slug: str) -> dict:
    r = await client.get(f"{BASE}/channels/{slug.strip().lstrip('@').lower()}", timeout=45)
    r.raise_for_status()
    return normalize_channel(r.json())


async def fetch_videos(client: httpx.AsyncClient, slug: str, limit: int) -> list[dict]:
    slug = slug.strip().lstrip("@").lower()
    r = await client.get(f"{BASE}/channels/{slug}/videos", timeout=60)
    r.raise_for_status()
    data = r.json()
    items = data if isinstance(data, list) else (data.get("data") or [])
    return [normalize_video(v, slug) for v in items[:limit]]


async def fetch_category(client: httpx.AsyncClient, slug: str, limit: int) -> list[dict]:
    """Live channels currently streaming in a category — the discovery path."""
    out: list[dict] = []
    page = 1
    while len(out) < limit and page <= 20:
        r = await client.get(f"{BASE}/categories/{slug}/livestreams",
                             params={"page": page, "limit": 50}, timeout=60)
        if r.status_code == 404:
            break
        r.raise_for_status()
        j = r.json()
        items = j.get("data") if isinstance(j, dict) else j
        if not items:
            break
        for ls in items:
            ch = (ls.get("channel") or {}) if isinstance(ls, dict) else {}
            cats = _categories(ls.get("categories"))
            out.append({
                "type": "live_channel",
                "category_slug": slug,
                "channel_id": ls.get("channel_id") or ch.get("id"),
                "slug": ch.get("slug") or ls.get("slug"),
                "username": (ch.get("user") or {}).get("username") or ls.get("username"),
                "live_title": ls.get("session_title"),
                "live_viewers": _i(ls.get("viewer_count")),
                "live_started_at": ls.get("start_time") or ls.get("created_at"),
                "is_mature": bool(ls.get("is_mature")),
                "language": ls.get("language"),
                "categories": cats,
                "thumbnail": _img(ls.get("thumbnail")),
                "channel_url": f"https://kick.com/{ch.get('slug') or ls.get('slug')}",
                "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            })
        page += 1
    return out[:limit]
