"""End-to-end run against mocked exchange APIs."""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_sources import KALSHI_MARKET, POLY_MARKET  # noqa: E402

MATCHING_POLY = {**POLY_MARKET, "id": "999",
                 "question": "Will the high temperature in NYC be above 79.5 degrees on Sep 8?",
                 "slug": "nyc-high-sep-8", "outcomePrices": ["0.60", "0.40"], "spread": 0.02,
                 "volume": 50000}


def _wire(monkeypatch, inp):
    from apify import Actor
    monkeypatch.delenv("APIFY_TOKEN", raising=False)

    async def fake_input():
        return inp
    monkeypatch.setattr(Actor, "get_input", staticmethod(fake_input))

    pushed, charged, stored = [], [], {}

    async def fake_push(data, *, charged_event_name=None):
        rows = data if isinstance(data, list) else [data]
        pushed.extend(rows)
        charged.extend([charged_event_name] * len(rows))
    monkeypatch.setattr(Actor, "push_data", staticmethod(fake_push))

    async def fake_set_value(key, value, **kw):
        stored[key] = value
    monkeypatch.setattr(Actor, "set_value", staticmethod(fake_set_value))
    return pushed, charged, stored


@pytest.mark.asyncio
@respx.mock
async def test_full_run_returns_markets_and_gaps(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get("https://api.elections.kalshi.com/trade-api/v2/markets").mock(
        return_value=httpx.Response(200, json={"markets": [KALSHI_MARKET], "cursor": None}))
    respx.get("https://gamma-api.polymarket.com/markets").mock(
        return_value=httpx.Response(200, json=[MATCHING_POLY, POLY_MARKET]))

    pushed, charged, stored = _wire(monkeypatch, {
        "exchanges": ["kalshi", "polymarket"], "status": "open",
        "maxMarkets": 100, "crossExchangeGaps": True, "matchThreshold": "0.5"})

    from src.main import main
    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0

    assert stored["SUMMARY"] == {"market": 3, "cross_exchange_match": 1, "errors": 0}
    assert set(charged) == {"market", "cross-exchange-match"}

    gap = next(r for r in pushed if r["type"] == "cross_exchange_match")
    assert gap["probability_gap"] == pytest.approx(0.16)
    assert gap["gap_exceeds_spreads"] is True

    markets = [r for r in pushed if r["type"] == "market"]
    vols = [m.get("volume_24h") or m.get("volume") or 0 for m in markets]
    assert vols == sorted(vols, reverse=True), "markets must come back sorted by liquidity"


@pytest.mark.asyncio
@respx.mock
async def test_search_filter_and_min_volume(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get("https://api.elections.kalshi.com/trade-api/v2/markets").mock(
        return_value=httpx.Response(200, json={"markets": [KALSHI_MARKET], "cursor": None}))
    respx.get("https://gamma-api.polymarket.com/markets").mock(
        return_value=httpx.Response(200, json=[POLY_MARKET]))

    pushed, _, stored = _wire(monkeypatch, {
        "exchanges": ["kalshi", "polymarket"], "search": ["temperature"],
        "maxMarkets": 50, "crossExchangeGaps": False, "scanLimit": 200})

    from src.main import main
    with pytest.raises(SystemExit):
        await main()

    assert stored["SUMMARY"]["market"] == 1
    assert "temperature" in pushed[0]["question"].lower()


@pytest.mark.asyncio
@respx.mock
async def test_one_exchange_down_still_returns_the_other(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get("https://api.elections.kalshi.com/trade-api/v2/markets").mock(
        return_value=httpx.Response(503, text="down"))
    respx.get("https://gamma-api.polymarket.com/markets").mock(
        return_value=httpx.Response(200, json=[POLY_MARKET]))

    pushed, _, stored = _wire(monkeypatch, {"exchanges": ["kalshi", "polymarket"], "maxMarkets": 50})

    from src.main import main
    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0

    assert stored["SUMMARY"]["errors"] == 1
    assert stored["SUMMARY"]["market"] == 1
    assert pushed[0]["exchange"] == "polymarket"


@pytest.mark.asyncio
@respx.mock
async def test_each_exchange_keeps_its_share_of_the_quota(tmp_path, monkeypatch):
    """Regression: Polymarket volumes are orders of magnitude larger than Kalshi's, so a
    pooled sort by volume took every slot and left cross-exchange matching with nothing."""
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    kalshi = [{**KALSHI_MARKET, "ticker": f"K-{i}", "volume_fp": 100 + i} for i in range(50)]
    poly = [{**POLY_MARKET, "id": str(i), "question": f"Poly question {i}",
             "volume": 10_000_000 + i} for i in range(50)]
    respx.get("https://api.elections.kalshi.com/trade-api/v2/markets").mock(
        return_value=httpx.Response(200, json={"markets": kalshi, "cursor": None}))
    respx.get("https://gamma-api.polymarket.com/markets").mock(
        return_value=httpx.Response(200, json=poly))

    pushed, _, stored = _wire(monkeypatch, {
        "exchanges": ["kalshi", "polymarket"], "maxMarkets": 20, "crossExchangeGaps": False})

    from src.main import main
    with pytest.raises(SystemExit):
        await main()

    kept = [r for r in pushed if r["type"] == "market"]
    by_ex = {e: sum(1 for r in kept if r["exchange"] == e) for e in ("kalshi", "polymarket")}
    assert len(kept) == 20
    assert by_ex["kalshi"] == 10 and by_ex["polymarket"] == 10, \
        f"both exchanges must survive the quota, got {by_ex}"
