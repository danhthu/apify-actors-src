"""End-to-end run against mocked exchange APIs."""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_sources import CANDLE_NESTED, POLY_HISTORY  # noqa: E402


def _wire(monkeypatch, inp):
    from apify import Actor
    monkeypatch.delenv("APIFY_TOKEN", raising=False)

    async def fake_input():
        return inp
    monkeypatch.setattr(Actor, "get_input", staticmethod(fake_input))

    pushed, charged, stored = [], [], {}

    async def fake_push(data, *, charged_event_name=None):
        rows = data if isinstance(data, list) else [data]
        pushed.extend(rows)
        charged.extend([charged_event_name] * len(rows))
    monkeypatch.setattr(Actor, "push_data", staticmethod(fake_push))

    async def fake_set_value(key, value, **kw):
        stored[key] = value
    monkeypatch.setattr(Actor, "set_value", staticmethod(fake_set_value))
    return pushed, charged, stored


@pytest.mark.asyncio
@respx.mock
async def test_explicit_tickers_pull_history_from_both_exchanges(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get(url__regex=r".*/candlesticks").mock(
        return_value=httpx.Response(200, json={"candlesticks": [CANDLE_NESTED] * 4, "ticker": "x"}))
    respx.get("https://clob.polymarket.com/prices-history").mock(
        return_value=httpx.Response(200, json=POLY_HISTORY))

    pushed, charged, stored = _wire(monkeypatch, {
        "kalshiTickers": ["KXHIGHNY-26SEP07-B79.5"],
        "polymarketTokenIds": ["tokenYES"],
        "granularityMinutes": 60, "includeSummary": True, "includePricePoints": True})

    from src.main import main
    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0

    s = stored["SUMMARY"]
    assert s["price_point"] == 7, "4 Kalshi candles + 3 Polymarket points"
    assert s["market_summary"] == 2
    assert s["errors"] == 0
    assert set(charged) == {"price-point", "market-summary"}

    exchanges = {r["exchange"] for r in pushed if r["type"] == "price_point"}
    assert exchanges == {"kalshi", "polymarket"}


@pytest.mark.asyncio
@respx.mock
async def test_summary_only_mode_bills_no_price_points(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get(url__regex=r".*/candlesticks").mock(
        return_value=httpx.Response(200, json={"candlesticks": [CANDLE_NESTED] * 100, "ticker": "x"}))

    pushed, charged, stored = _wire(monkeypatch, {
        "kalshiTickers": ["KXHIGHNY-26SEP07-B79.5"],
        "includePricePoints": False, "includeSummary": True})

    from src.main import main
    with pytest.raises(SystemExit):
        await main()

    assert stored["SUMMARY"]["price_point"] == 0
    assert stored["SUMMARY"]["market_summary"] == 1
    assert charged == ["market-summary"], "the caller must not be billed for points they turned off"
    assert pushed[0]["points"] == 100, "the summary still describes all 100 points"


@pytest.mark.asyncio
@respx.mock
async def test_max_points_caps_cost(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get(url__regex=r".*/candlesticks").mock(
        return_value=httpx.Response(200, json={"candlesticks": [CANDLE_NESTED] * 500, "ticker": "x"}))

    _, _, stored = _wire(monkeypatch, {
        "kalshiTickers": ["A-B-C"], "maxPointsPerMarket": 10, "includeSummary": False})

    from src.main import main
    with pytest.raises(SystemExit):
        await main()
    assert stored["SUMMARY"]["price_point"] == 10


@pytest.mark.asyncio
@respx.mock
async def test_discovery_by_search_then_history(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get("https://api.elections.kalshi.com/trade-api/v2/markets").mock(
        return_value=httpx.Response(200, json={"markets": [
            {"ticker": "KXHIGHNY-26SEP07-B79.5", "title": "Will the maximum temperature be 79-80?",
             "status": "active", "close_time": "2026-09-07T23:30:00Z"},
            {"ticker": "KXFED-26SEP-CUT", "title": "Will the Fed cut rates?", "status": "active"},
        ], "cursor": None}))
    respx.get(url__regex=r".*/candlesticks").mock(
        return_value=httpx.Response(200, json={"candlesticks": [CANDLE_NESTED] * 2, "ticker": "x"}))

    pushed, _, stored = _wire(monkeypatch, {
        "exchanges": ["kalshi"], "search": ["temperature"], "maxMarkets": 10,
        "includeSummary": True})

    from src.main import main
    with pytest.raises(SystemExit):
        await main()

    assert stored["SUMMARY"]["markets_scanned"] == 1, "only the temperature market matched"
    assert stored["SUMMARY"]["price_point"] == 2
    assert all("temperature" in (r.get("question") or "").lower()
               for r in pushed if r["type"] == "market_summary")


@pytest.mark.asyncio
@respx.mock
async def test_one_dead_market_does_not_kill_the_run(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))

    def responder(request):
        if "DEAD" in str(request.url):
            return httpx.Response(500, text="boom")
        return httpx.Response(200, json={"candlesticks": [CANDLE_NESTED], "ticker": "x"})

    respx.get(url__regex=r".*/candlesticks").mock(side_effect=responder)

    _, _, stored = _wire(monkeypatch, {
        "kalshiTickers": ["DEAD-1-X", "GOOD-1-X"], "includeSummary": False})

    from src.main import main
    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0
    assert stored["SUMMARY"]["errors"] == 1
    assert stored["SUMMARY"]["price_point"] == 1
