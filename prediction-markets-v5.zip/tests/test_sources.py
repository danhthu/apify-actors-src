"""Offline tests against verbatim captures of the live Kalshi and Polymarket responses."""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.sources import (  # noqa: E402
    cross_exchange_matches, fetch_kalshi, fetch_polymarket,
    normalize_kalshi, normalize_polymarket, similarity,
)

# Real shape returned by api.elections.kalshi.com (dollars variant).
KALSHI_MARKET = {
    "ticker": "KXHIGHNY-26SEP08-B79.5",
    "event_ticker": "KXHIGHNY-26SEP08",
    "series_ticker": "KXHIGHNY",
    "title": "Will the high temperature in NYC be above 79.5 degrees on Sep 8?",
    "yes_sub_title": "Above 79.5",
    "no_sub_title": "79.5 or below",
    "yes_bid_dollars": 0.4200,
    "yes_ask_dollars": 0.4600,
    "no_bid_dollars": 0.5400,
    "no_ask_dollars": 0.5800,
    "last_price_dollars": 0.4400,
    "volume_fp": 15320.00,
    "volume_24h_fp": 4210.00,
    "open_interest_fp": 8800.00,
    "open_time": "2026-09-06T05:26:41Z",
    "close_time": "2026-09-08T23:30:00Z",
    "expiration_time": "2026-09-08T23:30:00Z",
    "status": "active",
    "result": "",
    "strike_type": "greater",
    "floor_strike": 79.5,
    "rules_primary": "Settles on the NWS Daily Climate Report for Central Park.",
}

# Older/cents variant of the same API - must normalize to the same numbers.
KALSHI_CENTS = {
    "ticker": "KXHIGHNY-26SEP08-B79.5", "event_ticker": "KXHIGHNY-26SEP08",
    "title": "Will the high temperature in NYC be above 79.5 degrees on Sep 8?",
    "yes_bid": 42, "yes_ask": 46, "last_price": 44, "volume": 15320,
    "status": "active",
}

# Real shape returned by gamma-api.polymarket.com.
POLY_MARKET = {
    "id": "559651",
    "question": "Xi Jinping out before 2027?",
    "slug": "xi-jinping-out-before-2027",
    "conditionId": "0xa467b14d51f01b957109d9cbb1d6c124fab2a089d52ed8f471d23c2812e743b7",
    "outcomes": ["Yes", "No"],
    "outcomePrices": ["0.0425", "0.9575"],
    "volume": 13006972.532821974,
    "liquidity": 213387.0214,
    "startDate": "2025-07-03T20:37:00.228Z",
    "endDate": "2027-01-01T04:59:00Z",
    "active": True,
    "closed": False,
    "description": "This market will resolve to 'Yes' if China's General Secretary is removed from power.",
    "clobTokenIds": ["3233822019007135143577280177972530224457577521641332595144381601799462999340"],
}


def test_kalshi_dollars_normalization():
    m = normalize_kalshi(KALSHI_MARKET)
    assert m["exchange"] == "kalshi"
    assert m["market_id"] == "KXHIGHNY-26SEP08-B79.5"
    assert m["series_id"] == "KXHIGHNY"
    assert m["yes_bid"] == 0.42 and m["yes_ask"] == 0.46
    assert m["mid_price"] == 0.44
    assert m["implied_probability"] == 0.44
    assert m["spread"] == pytest.approx(0.04)
    assert m["volume"] == 15320.0 and m["volume_24h"] == 4210.0
    assert m["open_interest"] == 8800.0
    assert m["floor_strike"] == 79.5
    assert m["result"] is None, "an empty result string must become None"
    assert m["url"] == "https://kalshi.com/markets/kxhighny"


def test_kalshi_cents_variant_gives_same_prices():
    a = normalize_kalshi(KALSHI_MARKET)
    b = normalize_kalshi(KALSHI_CENTS)
    assert b["yes_bid"] == a["yes_bid"] == 0.42
    assert b["yes_ask"] == a["yes_ask"] == 0.46
    assert b["last_price"] == a["last_price"] == 0.44
    assert b["volume"] == a["volume"] == 15320.0


def test_polymarket_normalization_picks_the_yes_outcome():
    m = normalize_polymarket(POLY_MARKET)
    assert m["exchange"] == "polymarket"
    assert m["market_id"] == "559651"
    assert m["implied_probability"] == 0.0425, "must read the Yes leg, not the first price blindly"
    assert m["outcomes"] == ["Yes", "No"]
    assert m["outcome_prices"] == [0.0425, 0.9575]
    assert m["status"] == "active"
    assert m["volume"] == pytest.approx(13006972.53)
    assert m["url"] == "https://polymarket.com/event/xi-jinping-out-before-2027"


def test_polymarket_handles_json_encoded_string_arrays():
    """Gamma sometimes returns outcomes/outcomePrices as JSON strings rather than arrays."""
    m = normalize_polymarket({**POLY_MARKET,
                              "outcomes": '["Yes", "No"]',
                              "outcomePrices": '["0.61", "0.39"]'})
    assert m["outcomes"] == ["Yes", "No"]
    assert m["implied_probability"] == 0.61


def test_polymarket_closed_status():
    assert normalize_polymarket({**POLY_MARKET, "closed": True})["status"] == "closed"


def test_similarity_scores_related_questions_higher():
    a = "Will the high temperature in NYC be above 79.5 degrees on Sep 8?"
    b = "Highest temperature in New York City on September 8 above 79.5?"
    c = "Will the Fed cut rates in September?"
    assert similarity(a, b) > similarity(a, c)
    assert similarity(a, a) == 1.0


def test_cross_exchange_matching_and_gap_flag():
    k = normalize_kalshi(KALSHI_MARKET)                       # implied 0.44, spread 0.04
    p = normalize_polymarket({**POLY_MARKET,
                              "question": "Will the high temperature in NYC be above 79.5 degrees on Sep 8?",
                              "outcomePrices": ["0.60", "0.40"], "spread": 0.02})
    unrelated = normalize_polymarket(POLY_MARKET)

    matches = cross_exchange_matches([k, p, unrelated], threshold=0.5)
    assert len(matches) == 1, "only the genuinely matching pair is reported"
    m = matches[0]
    assert m["type"] == "cross_exchange_match"
    assert m["kalshi_probability"] == 0.44 and m["polymarket_probability"] == 0.60
    assert m["probability_gap"] == pytest.approx(0.16)
    assert m["combined_spread"] == pytest.approx(0.06)
    assert m["gap_exceeds_spreads"] is True
    assert m["match_score"] == 1.0


def test_cross_exchange_ignores_pairs_below_threshold():
    k = normalize_kalshi(KALSHI_MARKET)
    p = normalize_polymarket(POLY_MARKET)
    assert cross_exchange_matches([k, p], threshold=0.5) == []


@pytest.mark.asyncio
@respx.mock
async def test_fetch_kalshi_follows_the_cursor():
    calls = {"n": 0}

    def responder(request):
        calls["n"] += 1
        if calls["n"] == 1:
            return httpx.Response(200, json={"markets": [KALSHI_MARKET] * 2, "cursor": "abc"})
        return httpx.Response(200, json={"markets": [KALSHI_MARKET], "cursor": None})

    respx.get("https://api.elections.kalshi.com/trade-api/v2/markets").mock(side_effect=responder)
    async with httpx.AsyncClient() as c:
        rows = await fetch_kalshi(c, limit=10, status="open")
    assert len(rows) == 3 and calls["n"] == 2


@pytest.mark.asyncio
@respx.mock
async def test_fetch_kalshi_respects_the_limit():
    respx.get("https://api.elections.kalshi.com/trade-api/v2/markets").mock(
        return_value=httpx.Response(200, json={"markets": [KALSHI_MARKET] * 50, "cursor": "next"}))
    async with httpx.AsyncClient() as c:
        rows = await fetch_kalshi(c, limit=5, status="open")
    assert len(rows) == 5, "must not bill for more rows than the caller asked for"


@pytest.mark.asyncio
@respx.mock
async def test_fetch_polymarket_pages_until_short_page():
    pages = [[POLY_MARKET] * 100, [POLY_MARKET] * 3]

    def responder(request):
        return httpx.Response(200, json=pages.pop(0) if pages else [])

    respx.get("https://gamma-api.polymarket.com/markets").mock(side_effect=responder)
    async with httpx.AsyncClient() as c:
        rows = await fetch_polymarket(c, limit=500, status="open")
    assert len(rows) == 103
