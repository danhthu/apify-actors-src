"""End-to-end run of the actor against mocked upstreams, using local Apify storage."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_sources import IEM_REAL, NWS_OBS, OPEN_METEO_MULTI  # noqa: E402


@pytest.mark.asyncio
@respx.mock
async def test_full_run_writes_all_three_record_types(tmp_path, monkeypatch):
    monkeypatch.setenv("APIFY_LOCAL_STORAGE_DIR", str(tmp_path / "storage"))
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "storage"))
    monkeypatch.setenv("APIFY_INPUT_KEY", "INPUT")
    monkeypatch.delenv("APIFY_TOKEN", raising=False)
    monkeypatch.delenv("APIFY_IS_AT_HOME", raising=False)

    respx.get("https://mesonet.agron.iastate.edu/json/cli.py").mock(
        return_value=httpx.Response(200, json=IEM_REAL))
    respx.get(url__regex=r"https://api\.weather\.gov/stations/.+/observations").mock(
        return_value=httpx.Response(200, json=NWS_OBS))
    respx.get("https://api.open-meteo.com/v1/forecast").mock(
        return_value=httpx.Response(200, json=OPEN_METEO_MULTI))

    from apify import Actor
    from src.main import main

    async def fake_input():
        return {
            "stations": ["KNYC"],
            "includeClimate": True,
            "includeObservations": True,
            "includeForecast": True,
            "startDate": "2026-01-01",
            "endDate": "2026-01-31",
            "forecastDays": 2,
            "models": ["gfs_seamless", "ecmwf_ifs025"],
        }

    monkeypatch.setattr(Actor, "get_input", staticmethod(fake_input))

    pushed: list[dict] = []
    charged: list[str] = []

    async def fake_push(data, *, charged_event_name=None):
        rows = data if isinstance(data, list) else [data]
        pushed.extend(rows)
        charged.extend([charged_event_name] * len(rows))

    monkeypatch.setattr(Actor, "push_data", staticmethod(fake_push))

    stored: dict = {}

    async def fake_set_value(key, value, **kw):
        stored[key] = value

    monkeypatch.setattr(Actor, "set_value", staticmethod(fake_set_value))

    with pytest.raises(SystemExit) as exc:   # Actor context manager exits the process on success
        await main()
    assert exc.value.code == 0

    kinds = {r["type"] for r in pushed}
    assert kinds == {"climate_day", "observation", "forecast_day"}

    # every row is billed under the right event
    for row, event in zip(pushed, charged):
        expected = {"climate_day": "climate-day", "observation": "observation",
                    "forecast_day": "forecast-day"}[row["type"]]
        assert event == expected, f"{row['type']} was charged as {event}"

    summary = stored["SUMMARY"]
    assert summary["errors"] == 0
    assert summary["climate_day"] == 2
    assert summary["observation"] == 1
    assert summary["forecast_day"] == 6  # 2 models x 2 days + 2 consensus rows

    # station is stamped onto forecast rows so a multi-station run stays joinable
    assert all(r.get("station") == "KNYC" for r in pushed if r["type"] == "forecast_day")


@pytest.mark.asyncio
@respx.mock
async def test_one_failing_source_does_not_abort_the_run(tmp_path, monkeypatch):
    monkeypatch.setenv("APIFY_LOCAL_STORAGE_DIR", str(tmp_path / "storage"))
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "storage"))
    monkeypatch.delenv("APIFY_TOKEN", raising=False)

    respx.get("https://mesonet.agron.iastate.edu/json/cli.py").mock(
        return_value=httpx.Response(500, text="upstream down"))
    respx.get("https://api.open-meteo.com/v1/forecast").mock(
        return_value=httpx.Response(200, json=OPEN_METEO_MULTI))

    from apify import Actor
    from src.main import main

    monkeypatch.setattr(Actor, "get_input", staticmethod(
        lambda: __import__("asyncio").sleep(0, result={
            "stations": ["KNYC"], "includeClimate": True, "includeObservations": False,
            "includeForecast": True, "forecastDays": 2,
            "models": ["gfs_seamless", "ecmwf_ifs025"],
        })))

    pushed: list[dict] = []

    async def fake_push(data, *, charged_event_name=None):
        pushed.extend(data if isinstance(data, list) else [data])

    monkeypatch.setattr(Actor, "push_data", staticmethod(fake_push))

    stored: dict = {}

    async def fake_set_value(key, value, **kw):
        stored[key] = value

    monkeypatch.setattr(Actor, "set_value", staticmethod(fake_set_value))

    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0, "a failing upstream must not fail the whole run"

    assert stored["SUMMARY"]["errors"] == 1, "the failing climate source is counted"
    assert stored["SUMMARY"]["forecast_day"] == 6, "forecasts still delivered"
    assert any(r["type"] == "forecast_day" for r in pushed)
