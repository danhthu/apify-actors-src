"""End-to-end run against a mocked Kick API."""
from __future__ import annotations

import sys
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tests.test_sources import CHANNEL_LIVE, CHANNEL_OFFLINE, LIVE_ITEM, VIDEO  # noqa: E402


def _wire(monkeypatch, inp):
    from apify import Actor
    monkeypatch.delenv("APIFY_TOKEN", raising=False)

    async def fake_input():
        return inp
    monkeypatch.setattr(Actor, "get_input", staticmethod(fake_input))

    async def fake_proxy(**kw):
        return None
    monkeypatch.setattr(Actor, "create_proxy_configuration", staticmethod(fake_proxy))

    pushed, charged, stored = [], [], {}

    async def fake_push(data, *, charged_event_name=None):
        rows = data if isinstance(data, list) else [data]
        pushed.extend(rows)
        charged.extend([charged_event_name] * len(rows))
    monkeypatch.setattr(Actor, "push_data", staticmethod(fake_push))

    async def fake_set_value(key, value, **kw):
        stored[key] = value
    monkeypatch.setattr(Actor, "set_value", staticmethod(fake_set_value))
    return pushed, charged, stored


@pytest.mark.asyncio
@respx.mock
async def test_channels_videos_and_category_discovery(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get("https://kick.com/api/v2/channels/xqc").mock(
        return_value=httpx.Response(200, json=CHANNEL_LIVE))
    respx.get("https://kick.com/api/v2/channels/adinross").mock(
        return_value=httpx.Response(200, json=CHANNEL_OFFLINE))
    respx.get(url__regex=r"https://kick\.com/api/v2/channels/\w+/videos").mock(
        return_value=httpx.Response(200, json=[VIDEO] * 4))
    respx.get("https://kick.com/api/v2/categories/just-chatting/livestreams").mock(
        side_effect=[httpx.Response(200, json={"data": [
            {**LIVE_ITEM, "viewer_count": 100},
            {**LIVE_ITEM, "viewer_count": 9000},
            {**LIVE_ITEM, "viewer_count": 50},
        ]}), httpx.Response(200, json={"data": []})])

    pushed, charged, stored = _wire(monkeypatch, {
        "channels": ["xqc", "adinross"], "categories": ["just-chatting"],
        "includeVideos": True, "videosPerChannel": 4, "minViewers": 60})

    from src.main import main
    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0

    s = stored["SUMMARY"]
    assert s["channel"] == 2
    assert s["video"] == 8, "4 videos for each of the 2 channels"
    assert s["live_channel"] == 2, "the 50-viewer stream is filtered out by minViewers"
    assert s["errors"] == 0

    assert set(charged) == {"channel", "video", "live-channel"}

    live_rows = [r for r in pushed if r["type"] == "live_channel"]
    assert [r["live_viewers"] for r in live_rows] == [9000, 100], "sorted by viewers, highest first"


@pytest.mark.asyncio
@respx.mock
async def test_missing_channel_does_not_stop_the_others(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    respx.get("https://kick.com/api/v2/channels/ghost").mock(
        return_value=httpx.Response(404, json={}))
    respx.get("https://kick.com/api/v2/channels/xqc").mock(
        return_value=httpx.Response(200, json=CHANNEL_OFFLINE))

    pushed, _, stored = _wire(monkeypatch, {"channels": ["ghost", "xqc"], "includeVideos": False})

    from src.main import main
    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0

    assert stored["SUMMARY"] == {"channel": 1, "video": 0, "live_channel": 0, "errors": 1}
    assert pushed[0]["slug"] == "xqc"


@pytest.mark.asyncio
async def test_empty_input_exits_cleanly(tmp_path, monkeypatch):
    monkeypatch.setenv("CRAWLEE_STORAGE_DIR", str(tmp_path / "s"))
    _, _, stored = _wire(monkeypatch, {"channels": [], "categories": []})

    from src.main import main
    with pytest.raises(SystemExit) as exc:
        await main()
    assert exc.value.code == 0
    assert stored["SUMMARY"]["channel"] == 0
