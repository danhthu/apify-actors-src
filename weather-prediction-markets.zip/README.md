# Weather Data for Prediction Markets — Kalshi & Polymarket Temperature Markets

Get the **official settlement numbers**, live observations and **6-model forecasts with the disagreement between models**, for the weather stations that Kalshi and Polymarket temperature markets resolve on. One actor, one schema, no API keys.

If you trade "Highest temperature in NYC today" or any daily high/low market, the three questions you need answered every morning are:

1. What number will this actually settle on, and what did it do on this date historically?
2. What do the models say right now?
3. Where do the models disagree — because that is where the price is wrong.

This actor answers all three in a single run.

## Why this one and not a generic weather scraper

Generic weather actors give you an app forecast. Markets do not settle on an app forecast. US temperature markets settle on the **NWS Daily Climate Report (CLI product)** for a specific station — Central Park for New York, not "New York City" in general. This actor pulls that exact product, including the *time* the high was reached, the normal, and the record for that calendar day.

It also returns a **consensus row per day** carrying `tmax_spread` — how far apart the models are. A 1°F spread and an 8°F spread are two completely different trades on the same market.

## What you get

Three record types, each billed separately so you only pay for what you ask for.

### `climate_day` — the settlement value

```json
{
  "type": "climate_day",
  "station": "KNYC",
  "station_name": "NEW YORK CITY",
  "date": "2026-01-01",
  "high_f": 36,
  "high_time": "555 AM",
  "high_normal_f": 41,
  "high_record_f": 62,
  "low_f": 22,
  "low_time": "1012 PM",
  "precip_in": 0.02,
  "snow_in": 0.5,
  "max_gust_mph": 39,
  "avg_sky_cover": 0.4,
  "source": "NWS Daily Climate Report (CLI) via IEM",
  "source_url": "https://mesonet.agron.iastate.edu/api/1/nwstext/202601021606-KOKX-CDUS41-CLINYC"
}
```

Note `high_time`: the high came at 5:55 AM, not in the afternoon. That detail decides intraday markets and no consumer weather API gives it to you.

### `forecast_day` — every model, plus the spread

```json
{ "type": "forecast_day", "location": "New York City, NY (Central Park)", "date": "2026-09-08",
  "model": "ecmwf_ifs025", "tmax": 79.2, "tmin": 64.1, "temp_unit": "F", "precip_prob_max_pct": 15 }
```

```json
{ "type": "forecast_day", "date": "2026-09-08", "model": "consensus_mean",
  "tmax": 78.1, "tmin": 63.4, "models_count": 4, "tmax_spread": 3.6 }
```

Models available: **GFS** (USA), **ECMWF IFS** (Europe), **ICON** (Germany), **GEM** (Canada), **JMA** (Japan), and a blended best-match.

### `observation` — intraday

Hourly / METAR observations with temperature, dewpoint, wind, gusts, precipitation and the raw METAR string, so you can see how close today's high already is before the market closes.

## Stations covered for settlement data

KNYC (New York, Central Park), KLAX (Los Angeles), KORD (Chicago O'Hare), KAUS (Austin, Camp Mabry), KMIA (Miami), KDEN (Denver), KPHL (Philadelphia), KHOU (Houston Hobby), KSEA (Seattle), KBOS (Boston), KDCA (Washington DC National), KATL (Atlanta), KDFW (Dallas-Fort Worth), KPHX (Phoenix), KLAS (Las Vegas), KMSP (Minneapolis), KDTW (Detroit), KSFO (San Francisco).

Any other US station ID works too. For forecasts, **any city on earth** works — pass it in `cities` and it is geocoded automatically.

## Example input

Morning routine for the three biggest temperature markets:

```json
{
  "stations": ["KNYC", "KLAX", "KORD"],
  "includeClimate": true,
  "includeForecast": true,
  "historyDays": 30,
  "forecastDays": 7,
  "models": ["gfs_seamless", "ecmwf_ifs025", "icon_seamless", "best_match"],
  "temperatureUnit": "fahrenheit"
}
```

Backtesting a strategy over five years on one station:

```json
{ "stations": ["KNYC"], "includeClimate": true, "includeForecast": false,
  "startDate": "2021-01-01", "endDate": "2026-01-01" }
```

Worldwide forecasts, no US settlement data:

```json
{ "stations": [], "cities": ["London", "Tokyo", "Sydney"], "includeClimate": false, "forecastDays": 10 }
```

## Pricing

Pay per result. No monthly fee, no minimum.

| Record | Price |
|---|---|
| `climate_day` (settlement value) | $0.002 |
| `forecast_day` (per model per day) | $0.001 |
| `observation` (hourly) | $0.001 |

A daily run over three stations with 30 days of history and a 7-day, 4-model forecast costs roughly **$0.28**.

## Use it from an AI agent

The actor is callable through Apify's MCP server, so an agent can fetch settlement data and forecasts on its own. Ask for `weather-prediction-markets` with a station list and the record types you want.

## Data sources

- **NWS Daily Climate Report (CLI)** via Iowa Environmental Mesonet — the official product US temperature markets settle on.
- **api.weather.gov** — hourly and METAR observations.
- **Open-Meteo** — multi-model global forecasts.

All are public government or open data sources. No login, no scraping of a protected site, no rate-limit games.

## Notes and limits

- Daily climate reports are published by the local forecast office a few hours after midnight local time, so today's value appears the next morning. For today's number in progress, use `includeObservations`.
- `precip_in` and `snow_in` return `0.0` with `precip_trace: true` / `snow_trace: true` when the report says trace, so you can tell a trace from a real zero.
- Observations from api.weather.gov cover roughly the last 7 days.
- If a run hits your cost limit, the actor stops pushing rows and logs how many it skipped rather than failing.

## Support

Open an issue on the actor page. Requests for extra stations, extra models or a different output shape are welcome — this actor is actively maintained.
