# Prediction Market Price History — Kalshi & Polymarket Time Series for Backtesting

Historical price series for any **Kalshi** or **Polymarket** market, both exchanges normalized to one schema. OHLC candles where the exchange has them, tick prices where it does not, plus a per-market summary row so you can find the markets that actually moved before paying for their full series.

Find markets by keyword — you do not need to know Kalshi's ticker syntax.

## The problem this solves

Backtesting a prediction-market strategy means answering "what was this trading at three hours before it resolved?" Getting there yourself means: learn that a Kalshi candlestick lives at `/series/{series}/markets/{ticker}/candlesticks` and that the series is the first dash-segment of the ticker; learn that Polymarket history is keyed by a CLOB token id you have to dig out of `clobTokenIds`, and that the Yes leg is not reliably index 0; then reconcile cents against dollars and OHLC against single prices.

That is an afternoon before you have written a line of strategy. This actor is that afternoon, already done.

## Output

### `price_point`

```json
{
  "type": "price_point",
  "exchange": "kalshi",
  "market_id": "KXHIGHNY-26SEP07-B79.5",
  "question": "Will the maximum temperature be 79-80° on Sep 7, 2026?",
  "timestamp": 1788652800,
  "time_utc": "2026-09-06T00:00:00+00:00",
  "price": 0.47, "open": 0.42, "high": 0.51, "low": 0.40, "close": 0.47,
  "yes_bid": 0.46, "yes_ask": 0.48,
  "volume": 1200, "open_interest": 8800
}
```

Polymarket rows carry the same fields with `price`/`close` filled and OHLC null, so a single dataframe holds both exchanges without special-casing.

### `market_summary`

One row per market, sorted by widest range first:

```json
{
  "type": "market_summary",
  "market_id": "KXHIGHNY-26SEP07-B79.5",
  "points": 168, "first_price": 0.20, "last_price": 0.44,
  "min_price": 0.10, "max_price": 0.65, "range": 0.55, "change": 0.24,
  "first_time_utc": "2026-09-01T00:00:00+00:00",
  "last_time_utc": "2026-09-07T23:00:00+00:00"
}
```

Turn `includePricePoints` off and you get **only** these rows — a cheap scan to find which of 200 markets are worth pulling in full. Then re-run with points on for just those.

## Example input

Everything the New York temperature series did last month, hourly:

```json
{ "kalshiSeriesTicker": "KXHIGHNY", "status": "settled",
  "historyDays": 30, "granularityMinutes": 60, "maxMarkets": 50 }
```

Cheap scan first — summaries only, no per-tick billing:

```json
{ "search": ["fed", "cpi", "rates"], "maxMarkets": 200,
  "includePricePoints": false, "includeSummary": true }
```

Exact markets, daily granularity, both exchanges:

```json
{ "kalshiTickers": ["KXHIGHNY-26SEP07-B79.5"],
  "polymarketTokenIds": ["32338220190071351435772801779725302244575775216413325951443816017994629993401"],
  "granularityMinutes": 1440, "historyDays": 365 }
```

## Pricing

| Record | Price |
|---|---|
| `price_point` | $0.0003 |
| `market_summary` | $0.002 |

A year of daily prices for 50 markets is about 18,000 points ≈ **$5.50**. A summary-only scan of 200 markets is **$0.40**.

## Pairs with

- **Kalshi & Polymarket Market Data + Cross-Exchange Price Gaps** — live prices and arbitrage gaps.
- **Weather Data for Prediction Markets** — the NWS settlement values these temperature markets resolve against. Join price history to the actual outcome and you have a labelled dataset.

## Notes and limits

- Kalshi has shipped both a nested (`price.open`) and a flat candlestick shape, and both cents and dollars. Everything is normalized to dollars in 0–1 whichever arrives.
- Polymarket returns a single price per timestamp, not OHLC.
- A market with no trading in the requested window returns no rows and is logged, not treated as an error.
- Polymarket's price API only accepts a window of about a week per request, so longer ranges are walked in week-sized chunks and stitched together for you. You can ask for a year and it just works.
- Kalshi has no title search and tens of thousands of open markets, so a keyword may not reach the ones you want. Targeting a series (`kalshiSeriesTicker`, e.g. `KXHIGHNY`) or exact tickers is the reliable path; the run warns you when a keyword finds nothing.
- Every cost is bounded by `maxMarkets` × `maxPointsPerMarket`, so a wide date range cannot surprise you.
- Discovery scanning is not billed — only the rows you receive.

## Support

Open an issue on the actor page. Requests for other exchanges or extra fields are welcome.
