"""Kalshi and Polymarket public market data, normalized into one schema.

Both APIs are public and unauthenticated for market data. Field names differ between
API versions, so every read goes through `pick()` which tries the known variants.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

import httpx

UA = "prediction-markets-actor/1.0 (Apify actor)"
KALSHI = "https://api.elections.kalshi.com/trade-api/v2"
POLY_GAMMA = "https://gamma-api.polymarket.com"

_STOP = {
    "will", "the", "be", "a", "an", "of", "in", "on", "at", "to", "by", "for", "is", "are",
    "before", "after", "and", "or", "than", "this", "that", "it", "as", "with", "how", "many",
    "what", "who", "when", "which", "does", "do", "did", "any", "more", "less", "over", "under",
}


def pick(d: dict, *names, default=None):
    """First present, non-None value among the given field names."""
    for n in names:
        if n in d and d[n] is not None:
            return d[n]
    return default


def _price(d: dict, *names) -> float | None:
    """Kalshi returns prices either in cents (yes_bid) or dollars (yes_bid_dollars).
    Normalize everything to dollars in 0..1."""
    for n in names:
        v = d.get(n)
        if v is None:
            continue
        try:
            f = float(v)
        except (TypeError, ValueError):
            continue
        return round(f, 4) if n.endswith("_dollars") else round(f / 100.0, 4)
    return None


def _f(v) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def keywords(text: str) -> set[str]:
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    return {w for w in words if len(w) > 2 and w not in _STOP}


def similarity(a: str, b: str) -> float:
    ka, kb = keywords(a), keywords(b)
    if not ka or not kb:
        return 0.0
    return len(ka & kb) / len(ka | kb)


# --------------------------------------------------------------------------- #
# Kalshi
# --------------------------------------------------------------------------- #
def normalize_kalshi(m: dict) -> dict:
    yes_bid = _price(m, "yes_bid_dollars", "yes_bid")
    yes_ask = _price(m, "yes_ask_dollars", "yes_ask")
    last = _price(m, "last_price_dollars", "last_price")
    mid = round((yes_bid + yes_ask) / 2, 4) if yes_bid is not None and yes_ask is not None else None
    ticker = pick(m, "ticker", default="")
    return {
        "type": "market",
        "exchange": "kalshi",
        "market_id": ticker,
        "event_id": pick(m, "event_ticker"),
        "series_id": pick(m, "series_ticker"),
        "question": pick(m, "title", default=""),
        "subtitle": pick(m, "yes_sub_title", "subtitle"),
        "category": pick(m, "category"),
        "status": pick(m, "status"),
        "result": pick(m, "result") or None,
        "yes_bid": yes_bid,
        "yes_ask": yes_ask,
        "no_bid": _price(m, "no_bid_dollars", "no_bid"),
        "no_ask": _price(m, "no_ask_dollars", "no_ask"),
        "last_price": last,
        "mid_price": mid,
        "implied_probability": mid if mid is not None else last,
        "spread": round(yes_ask - yes_bid, 4) if yes_bid is not None and yes_ask is not None else None,
        "volume": _f(pick(m, "volume_fp", "volume")),
        "volume_24h": _f(pick(m, "volume_24h_fp", "volume_24h")),
        "open_interest": _f(pick(m, "open_interest_fp", "open_interest")),
        "liquidity": _f(pick(m, "liquidity_fp", "liquidity")),
        "open_time": pick(m, "open_time"),
        "close_time": pick(m, "close_time"),
        "expiration_time": pick(m, "expiration_time"),
        "strike_type": pick(m, "strike_type"),
        "floor_strike": _f(pick(m, "floor_strike")),
        "cap_strike": _f(pick(m, "cap_strike")),
        "rules": pick(m, "rules_primary") or None,
        "url": f"https://kalshi.com/markets/{ticker.split('-')[0].lower()}" if ticker else None,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


async def fetch_kalshi(client: httpx.AsyncClient, limit: int, status: str | None,
                       series: str | None = None, event: str | None = None) -> list[dict]:
    out: list[dict] = []
    cursor = None
    while len(out) < limit:
        params: dict = {"limit": min(1000, limit - len(out))}
        if status and status != "any":
            params["status"] = status
        if series:
            params["series_ticker"] = series
        if event:
            params["event_ticker"] = event
        if cursor:
            params["cursor"] = cursor
        r = await client.get(f"{KALSHI}/markets", params=params, timeout=60)
        r.raise_for_status()
        j = r.json()
        batch = j.get("markets") or []
        if not batch:
            break
        out.extend(normalize_kalshi(m) for m in batch)
        cursor = j.get("cursor")
        if not cursor:
            break
    return out[:limit]


# --------------------------------------------------------------------------- #
# Polymarket
# --------------------------------------------------------------------------- #
def _as_list(v):
    if isinstance(v, list):
        return v
    if isinstance(v, str):
        import json
        try:
            parsed = json.loads(v)
            return parsed if isinstance(parsed, list) else []
        except ValueError:
            return []
    return []


def normalize_polymarket(m: dict) -> dict:
    outcomes = _as_list(pick(m, "outcomes", default=[]))
    prices = [_f(p) for p in _as_list(pick(m, "outcomePrices", default=[]))]
    yes_price = None
    for name, p in zip(outcomes, prices):
        if str(name).strip().lower() == "yes":
            yes_price = p
            break
    if yes_price is None and prices:
        yes_price = prices[0]
    slug = pick(m, "slug", default="")
    spread = _f(pick(m, "spread"))
    return {
        "type": "market",
        "exchange": "polymarket",
        "market_id": str(pick(m, "id", default="")),
        "event_id": pick(m, "conditionId"),
        "series_id": None,
        "question": pick(m, "question", default=""),
        "subtitle": pick(m, "groupItemTitle"),
        "category": pick(m, "category"),
        "status": "closed" if pick(m, "closed", default=False) else ("active" if pick(m, "active", default=False) else "inactive"),
        "result": pick(m, "umaResolutionStatus"),
        "yes_bid": _f(pick(m, "bestBid")),
        "yes_ask": _f(pick(m, "bestAsk")),
        "no_bid": None,
        "no_ask": None,
        "last_price": _f(pick(m, "lastTradePrice")),
        "mid_price": yes_price,
        "implied_probability": yes_price,
        "spread": round(spread, 4) if spread is not None else None,
        "volume": _f(pick(m, "volume", "volumeNum")),
        "volume_24h": _f(pick(m, "volume24hr")),
        "open_interest": _f(pick(m, "openInterest")),
        "liquidity": _f(pick(m, "liquidity", "liquidityNum")),
        "open_time": pick(m, "startDate"),
        "close_time": pick(m, "endDate"),
        "expiration_time": pick(m, "endDate"),
        "outcomes": outcomes,
        "outcome_prices": prices,
        "rules": pick(m, "description"),
        "url": f"https://polymarket.com/event/{slug}" if slug else None,
        "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }


async def fetch_polymarket(client: httpx.AsyncClient, limit: int, status: str | None) -> list[dict]:
    out: list[dict] = []
    offset = 0
    page = 100
    while len(out) < limit:
        params: dict = {"limit": min(page, limit - len(out)), "offset": offset, "order": "volume24hr", "ascending": "false"}
        if status == "open":
            params["closed"] = "false"
            params["active"] = "true"
        elif status in ("closed", "settled"):
            params["closed"] = "true"
        r = await client.get(f"{POLY_GAMMA}/markets", params=params, timeout=60)
        r.raise_for_status()
        batch = r.json()
        if not isinstance(batch, list) or not batch:
            break
        out.extend(normalize_polymarket(m) for m in batch)
        offset += len(batch)
        if len(batch) < params["limit"]:
            break
    return out[:limit]


# --------------------------------------------------------------------------- #
# Cross-exchange matching
# --------------------------------------------------------------------------- #
def cross_exchange_matches(markets: list[dict], threshold: float = 0.5) -> list[dict]:
    """Find questions listed on both exchanges and report the price gap between them.
    A gap wider than the two spreads combined is where the arbitrage is."""
    kalshi = [m for m in markets if m["exchange"] == "kalshi" and m.get("implied_probability") is not None]
    poly = [m for m in markets if m["exchange"] == "polymarket" and m.get("implied_probability") is not None]
    out = []
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for k in kalshi:
        best, best_score = None, threshold
        for p in poly:
            s = similarity(k["question"], p["question"])
            if s > best_score:
                best, best_score = p, s
        if best:
            gap = round(abs(k["implied_probability"] - best["implied_probability"]), 4)
            spreads = (k.get("spread") or 0) + (best.get("spread") or 0)
            out.append({
                "type": "cross_exchange_match",
                "match_score": round(best_score, 3),
                "question_kalshi": k["question"],
                "question_polymarket": best["question"],
                "kalshi_market_id": k["market_id"],
                "polymarket_market_id": best["market_id"],
                "kalshi_probability": k["implied_probability"],
                "polymarket_probability": best["implied_probability"],
                "probability_gap": gap,
                "combined_spread": round(spreads, 4),
                "gap_exceeds_spreads": gap > spreads,
                "kalshi_volume": k.get("volume"),
                "polymarket_volume": best.get("volume"),
                "kalshi_close_time": k.get("close_time"),
                "polymarket_close_time": best.get("close_time"),
                "kalshi_url": k.get("url"),
                "polymarket_url": best.get("url"),
                "fetched_at": now,
            })
    out.sort(key=lambda r: r["probability_gap"], reverse=True)
    return out
