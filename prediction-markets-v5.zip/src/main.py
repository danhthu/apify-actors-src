"""Kalshi + Polymarket market data in one normalized schema, with cross-exchange price gaps."""
from __future__ import annotations

import asyncio

import httpx
from apify import Actor

from .sources import UA, cross_exchange_matches, fetch_kalshi, fetch_polymarket, keywords

EVENT_MARKET = "market"
EVENT_MATCH = "cross-exchange-match"


async def _budget(event_name: str, wanted: int) -> int:
    try:
        cm = Actor.get_charging_manager()
        allowed = cm.calculate_max_event_charge_count_within_limit(event_name)
    except Exception:
        return wanted
    return wanted if allowed is None else max(0, min(wanted, allowed))


async def _push(records: list[dict], event_name: str) -> int:
    if not records:
        return 0
    allowed = await _budget(event_name, len(records))
    if allowed < len(records):
        Actor.log.warning(f"Budget limit for '{event_name}': pushing {allowed} of {len(records)} rows.")
    records = records[:allowed]
    if not records:
        return 0
    await Actor.push_data(records, charged_event_name=event_name)
    return len(records)


def _matches_search(m: dict, terms: list[str]) -> bool:
    if not terms:
        return True
    hay = f"{m.get('question','')} {m.get('subtitle') or ''} {m.get('category') or ''} {m.get('market_id') or ''}".lower()
    return any(t.lower() in hay for t in terms)


async def main() -> None:
    async with Actor:
        inp = await Actor.get_input() or {}

        exchanges = [e.lower() for e in (inp.get("exchanges") or ["kalshi", "polymarket"])]
        search = [s.strip() for s in (inp.get("search") or []) if s and s.strip()]
        status = (inp.get("status") or "open").lower()
        max_markets = int(inp.get("maxMarkets") or 500)
        min_volume = float(inp.get("minVolume") or 0)
        find_gaps = bool(inp.get("crossExchangeGaps", True))
        threshold = float(inp.get("matchThreshold") or 0.35)
        series = (inp.get("kalshiSeriesTicker") or "").strip() or None
        event = (inp.get("kalshiEventTicker") or "").strip() or None

        # When the caller filters by keyword we must scan a wider pool before filtering.
        scan = max_markets if not search else max(max_markets, min(int(inp.get("scanLimit") or 3000), 20000))

        totals = {"market": 0, "cross_exchange_match": 0, "errors": 0}
        all_markets: list[dict] = []

        async with httpx.AsyncClient(headers={"User-Agent": UA}, follow_redirects=True) as client:
            if "kalshi" in exchanges:
                try:
                    rows = await fetch_kalshi(client, scan, status, series, event)
                    Actor.log.info(f"Kalshi: fetched {len(rows)} markets.")
                    all_markets.extend(rows)
                except Exception as e:
                    totals["errors"] += 1
                    Actor.log.exception(f"Kalshi fetch failed: {e}")

            if "polymarket" in exchanges:
                try:
                    rows = await fetch_polymarket(client, scan, status)
                    Actor.log.info(f"Polymarket: fetched {len(rows)} markets.")
                    all_markets.extend(rows)
                except Exception as e:
                    totals["errors"] += 1
                    Actor.log.exception(f"Polymarket fetch failed: {e}")

        filtered = [m for m in all_markets
                    if _matches_search(m, search) and (m.get("volume") or 0) >= min_volume]

        def liquidity(m):
            return m.get("volume_24h") or m.get("volume") or 0

        # Give each exchange its own share of the quota. Sorting the pooled list by volume
        # lets the exchange with larger raw numbers take every slot, which silently drops the
        # other exchange and leaves cross-exchange matching with nothing to compare.
        present = [e for e in ("kalshi", "polymarket")
                   if e in exchanges and any(m["exchange"] == e for m in filtered)]
        if len(present) > 1:
            per = max(1, max_markets // len(present))
            selected, taken = [], set()
            for ex in present:
                rows = sorted([m for m in filtered if m["exchange"] == ex], key=liquidity, reverse=True)[:per]
                selected.extend(rows)
                taken.update(id(m) for m in rows)
            if len(selected) < max_markets:
                rest = sorted([m for m in filtered if id(m) not in taken], key=liquidity, reverse=True)
                selected.extend(rest[: max_markets - len(selected)])
            for ex in present:
                Actor.log.info(f"{ex}: {sum(1 for m in selected if m['exchange'] == ex)} markets kept.")
        else:
            selected = sorted(filtered, key=liquidity, reverse=True)[:max_markets]
        selected.sort(key=liquidity, reverse=True)

        if search and not selected:
            Actor.log.warning(
                f"No markets matched {search} in the first {scan} markets. "
                "Raise 'scanLimit' or widen the search terms."
            )

        totals["market"] = await _push(selected, EVENT_MARKET)

        if find_gaps and len([e for e in exchanges if e in ("kalshi", "polymarket")]) == 2:
            matches = cross_exchange_matches(selected, threshold)
            Actor.log.info(f"Cross-exchange: {len(matches)} questions found on both exchanges.")
            totals["cross_exchange_match"] = await _push(matches, EVENT_MATCH)

        await Actor.set_value("SUMMARY", totals)
        Actor.log.info(f"Done. markets={totals['market']} matches={totals['cross_exchange_match']} errors={totals['errors']}")


if __name__ == "__main__":
    asyncio.run(main())
