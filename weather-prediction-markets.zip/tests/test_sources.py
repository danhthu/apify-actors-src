"""Offline tests. The IEM payload below is a verbatim capture of a real API response,
so the parsing is tested against the actual shape and quirks ('M' missing, 'T' trace)."""
from __future__ import annotations

import sys
from datetime import date, datetime, timezone
from pathlib import Path

import httpx
import pytest
import respx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.sources import _num, fetch_climate_days, fetch_forecasts, fetch_nws_observations, geocode  # noqa: E402

IEM_REAL = {
    "results": [
        {
            "station": "KNYC", "valid": "2026-01-01", "state": "NY", "wfo": "OKX",
            "link": "/api/1/nwstext/202601021606-KOKX-CDUS41-CLINYC",
            "product": "202601021606-KOKX-CDUS41-CLINYC", "name": "NEW YORK CITY",
            "high": 36, "high_record": 62, "high_record_years": [1966], "high_normal": 41,
            "high_depart": -5, "high_time": "555 AM",
            "low": 22, "low_record": -4, "low_record_years": [1918], "low_normal": 30,
            "low_depart": -8, "low_time": "1012 PM",
            "precip": 0.02, "precip_normal": 0.12, "precip_month": 0.02,
            "precip_jun1": "M", "precip_jul1": "M", "precip_record": 2.05,
            "snow": 0.5, "snowdepth": 1.0, "snow_normal": 0.2,
            "average_sky_cover": 0.4,
            "resultant_wind_speed": "M", "resultant_wind_direction": "M",
            "highest_wind_speed": 22, "highest_wind_direction": 300,
            "highest_gust_speed": 39, "highest_gust_direction": 250, "average_wind_speed": 9.6,
        },
        {
            "station": "KNYC", "valid": "2026-01-02", "state": "NY", "wfo": "OKX",
            "link": "/api/1/nwstext/202601030619-KOKX-CDUS41-CLINYC",
            "product": "202601030619-KOKX-CDUS41-CLINYC", "name": "NEW YORK CITY",
            "high": 30, "high_record": 68, "high_normal": 40, "high_time": "422 PM",
            "low": 20, "low_record": 2, "low_normal": 30, "low_time": "318 AM",
            "precip": "T", "precip_normal": 0.12,
            "snow": "T", "snowdepth": "T", "snow_normal": 0.2,
            "average_sky_cover": 1.0,
            "highest_wind_speed": 15, "highest_gust_speed": 23, "average_wind_speed": 6.3,
        },
        {  # outside the requested range - must be filtered out
            "station": "KNYC", "valid": "2026-02-15", "name": "NEW YORK CITY",
            "high": 50, "low": 30, "precip": 0.0, "snow": 0.0,
        },
    ]
}


def test_num_handles_missing_and_trace():
    assert _num("M") is None
    assert _num(None) is None
    assert _num("") is None
    assert _num("T") == 0.0
    assert _num(36) == 36.0
    assert _num("0.02") == 0.02


@pytest.mark.asyncio
@respx.mock
async def test_climate_days_parses_real_payload():
    respx.get("https://mesonet.agron.iastate.edu/json/cli.py").mock(
        return_value=httpx.Response(200, json=IEM_REAL)
    )
    async with httpx.AsyncClient() as client:
        rows = await fetch_climate_days(client, "knyc", date(2026, 1, 1), date(2026, 1, 31))

    assert len(rows) == 2, "the February record must be filtered out by the date range"
    a, b = rows

    assert a["type"] == "climate_day"
    assert a["station"] == "KNYC" and a["station_name"] == "NEW YORK CITY"
    assert a["high_f"] == 36.0 and a["high_time"] == "555 AM"
    assert a["high_normal_f"] == 41.0 and a["high_record_f"] == 62.0
    assert a["low_f"] == 22.0
    assert a["precip_in"] == 0.02 and a["precip_trace"] is False
    assert a["snow_in"] == 0.5 and a["snow_depth_in"] == 1.0
    assert a["max_gust_mph"] == 39.0 and a["avg_wind_mph"] == 9.6
    assert a["source_url"].startswith("https://mesonet.agron.iastate.edu/api/1/nwstext/")

    # trace values must read as 0.0 but stay distinguishable from a real zero
    assert b["precip_in"] == 0.0 and b["precip_trace"] is True
    assert b["snow_in"] == 0.0 and b["snow_trace"] is True


@pytest.mark.asyncio
@respx.mock
async def test_climate_days_spans_multiple_years():
    route = respx.get("https://mesonet.agron.iastate.edu/json/cli.py").mock(
        return_value=httpx.Response(200, json={"results": []})
    )
    async with httpx.AsyncClient() as client:
        await fetch_climate_days(client, "KNYC", date(2024, 12, 1), date(2026, 1, 5))
    assert route.call_count == 3, "one request per calendar year covered"


NWS_OBS = {
    "features": [
        {
            "properties": {
                "timestamp": "2026-09-06T14:51:00+00:00",
                "textDescription": "Mostly Cloudy",
                "rawMessage": "KNYC 061451Z 08007KT 10SM BKN035 24/18 A3006",
                "temperature": {"value": 23.9, "unitCode": "wmoUnit:degC"},
                "dewpoint": {"value": 17.8, "unitCode": "wmoUnit:degC"},
                "windSpeed": {"value": 13.0, "unitCode": "wmoUnit:km_h-1"},
                "windGust": {"value": None},
                "windDirection": {"value": 80},
                "relativeHumidity": {"value": 68.4},
                "barometricPressure": {"value": 101830},
                "precipitationLastHour": {"value": 0},
                "visibility": {"value": 16090},
            }
        }
    ]
}


@pytest.mark.asyncio
@respx.mock
async def test_observations_convert_celsius_to_fahrenheit():
    respx.get("https://api.weather.gov/stations/KNYC/observations").mock(
        return_value=httpx.Response(200, json=NWS_OBS)
    )
    async with httpx.AsyncClient() as client:
        rows = await fetch_nws_observations(
            client, "KNYC",
            datetime(2026, 9, 6, tzinfo=timezone.utc), datetime(2026, 9, 6, 23, tzinfo=timezone.utc),
        )
    assert len(rows) == 1
    r = rows[0]
    assert r["type"] == "observation"
    assert r["temp_c"] == 23.9 and r["temp_f"] == 75.0
    assert r["wind_kmh"] == 13.0
    assert r["wind_gust_kmh"] is None, "a null quantitative value must stay None, not crash"
    assert r["raw_metar"].startswith("KNYC 061451Z")


OPEN_METEO_MULTI = {
    "latitude": 40.78, "longitude": -73.97, "timezone": "America/New_York",
    "daily": {
        "time": ["2026-09-06", "2026-09-07"],
        "temperature_2m_max_gfs_seamless": [80.1, 82.4],
        "temperature_2m_min_gfs_seamless": [65.0, 66.2],
        "precipitation_sum_gfs_seamless": [0.0, 0.12],
        "precipitation_probability_max_gfs_seamless": [5, 40],
        "temperature_2m_max_ecmwf_ifs025": [77.5, 79.0],
        "temperature_2m_min_ecmwf_ifs025": [64.0, 65.1],
        "precipitation_sum_ecmwf_ifs025": [0.0, 0.20],
        "precipitation_probability_max_ecmwf_ifs025": [10, 55],
    },
}


@pytest.mark.asyncio
@respx.mock
async def test_forecasts_per_model_plus_consensus_and_spread():
    respx.get("https://api.open-meteo.com/v1/forecast").mock(
        return_value=httpx.Response(200, json=OPEN_METEO_MULTI)
    )
    async with httpx.AsyncClient() as client:
        rows = await fetch_forecasts(client, "NYC", 40.78, -73.97, 2,
                                     ["gfs_seamless", "ecmwf_ifs025"], "fahrenheit")

    per_model = [r for r in rows if r["model"] != "consensus_mean"]
    consensus = [r for r in rows if r["model"] == "consensus_mean"]
    assert len(per_model) == 4, "2 models x 2 days"
    assert len(consensus) == 2, "one consensus row per day"

    day1 = next(r for r in consensus if r["date"] == "2026-09-06")
    assert day1["tmax"] == pytest.approx((80.1 + 77.5) / 2, abs=0.05)
    assert day1["tmax_spread"] == pytest.approx(80.1 - 77.5, abs=0.05)
    assert day1["models_count"] == 2
    assert day1["temp_unit"] == "F"

    gfs = next(r for r in per_model if r["model"] == "gfs_seamless" and r["date"] == "2026-09-07")
    assert gfs["tmax"] == 82.4 and gfs["precip_prob_max_pct"] == 40
    assert gfs["issued_at_utc"].endswith("+00:00")


@pytest.mark.asyncio
@respx.mock
async def test_forecast_falls_back_to_unsuffixed_keys_for_single_model():
    respx.get("https://api.open-meteo.com/v1/forecast").mock(
        return_value=httpx.Response(200, json={
            "timezone": "UTC",
            "daily": {"time": ["2026-09-06"], "temperature_2m_max": [70.0],
                      "temperature_2m_min": [55.0], "precipitation_sum": [0.0],
                      "precipitation_probability_max": [0]},
        })
    )
    async with httpx.AsyncClient() as client:
        rows = await fetch_forecasts(client, "X", 1.0, 2.0, 1, ["best_match"], "fahrenheit")
    assert any(r["model"] == "best_match" and r["tmax"] == 70.0 for r in rows)


@pytest.mark.asyncio
@respx.mock
async def test_forecast_skips_models_that_return_nothing():
    respx.get("https://api.open-meteo.com/v1/forecast").mock(
        return_value=httpx.Response(200, json={
            "timezone": "UTC",
            "daily": {"time": ["2026-09-06"], "temperature_2m_max_gfs_seamless": [70.0],
                      "temperature_2m_min_gfs_seamless": [55.0]},
        })
    )
    async with httpx.AsyncClient() as client:
        rows = await fetch_forecasts(client, "X", 1.0, 2.0, 1, ["gfs_seamless", "jma_seamless"], "fahrenheit")
    models = {r["model"] for r in rows}
    assert "gfs_seamless" in models
    assert "jma_seamless" not in models, "a model with no data must be skipped, not pushed as nulls"


@pytest.mark.asyncio
@respx.mock
async def test_geocode_returns_none_when_not_found():
    respx.get("https://geocoding-api.open-meteo.com/v1/search").mock(
        return_value=httpx.Response(200, json={"generationtime_ms": 0.1})
    )
    async with httpx.AsyncClient() as client:
        assert await geocode(client, "Zzzz") is None
